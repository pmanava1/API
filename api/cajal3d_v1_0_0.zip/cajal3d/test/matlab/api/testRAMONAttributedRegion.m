function test_suite= testRAMONAttributedRegion%#ok<STOUT>
    %TESTSEED Unit test of the seed datatype
    
    %% Init the test suite
    initTestSuite;
    
    
end

function testNothing %#ok<*DEFNU>
    assertEqual(1,1);
end