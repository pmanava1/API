function matlabInitTFunctionNoArg()
    %matlabInitTestFunction Function used by the matlabInit unit test
    fprintf('IT WORKED!\n');  
end

