classdef OCP < handle
    %OCP ************************************************
    % Provides easy access to the Open Connectome Project database services
    %
    % Usage:
    %
    %  ocp = OCPInterface(); Creates object
    %
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    23-AUG-2011     Initial Release
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    properties(SetAccess = 'private', GetAccess = 'public')
        %% Properties - Server Info
        %Url to server root
        serverLocation = 'http://openconnecto.me' 

        batchSize = 20; % Number of annotations to group in a batch upload
        maxAnnoSize = 500000; % Maximum size of annotation in voxels to be uploaded in a single RESTful query
        
        %% Properties - Common Public
        defaultResolution = [] % Default resolution of the annotation DB
        
        %% Properties - DB Info
        imageInfo = []
        annoInfo = []
        
    end
    
    properties(SetAccess = 'private', GetAccess = 'private')
        %% Properties - Private
        lastQuery = [];
        lastUrl = []
        
        %Token for Image Database
        imageToken = []
        %Token for Annotation Database
        annoToken = []
        
        %% Properties - Utility Classes
        net = [];
    end
    
    methods( Access = public )
        
        %% Methods - General - Constructor
        function this = OCP(varargin)
            % No Semaphore to control OCP server resource access (default case)
            %   this = OCP()
            %
            % Distributed Semaphore (see OCPNetwork for details)
            %	this = OCP("darkhelmet.jhuapl.edu",3679,"readQ",10,0,"writeQ",20,100);
            
            
            % Set up network interface class
            switch nargin
                case 0
                    % No semaphore
                    this.net = OCPNetwork();
                    
                case 8
                    % Distributed semaphore
                    this.net = OCPNetwork(varargin{1},varargin{2},...
                        varargin{3},varargin{4},varargin{5},varargin{6},...
                        varargin{7},varargin{8});
                otherwise
                    ex = MException('OCP:InvalidConstructor','Invalid params to the constructor.');
                    throw(ex);
            end
            
            % Verify server url is valid by setting to self
            this.setServerLocation(this.serverLocation);
        end
        
        %% Methods - Semaphore
        function num = numReadPermits(this)
            num = this.net.numReadPermits();
        end
        function num = numWritePermits(this)
            num = this.net.numWritePermits();
        end
                
        % Select non-default database index if desired.  This lets you work
        % with different semaphores, allowing unit testing/development to
        % occur without conflicting with actual processing.
        % Run this AFTER creating object but BEFORE a reset or lock.
        function selectDatabaseIndex(this,index)
            this.net.selectDatabaseIndex(index)
        end
        
        %% Methods - General - Setters/Getters
        
        function this = setErrorPageLocation(this,location)
            % This method sets the path to save server errors pages to
            this.net.setErrorPageLocation(location);
        end
        function location = getErrorPageLocation(this)
            % This method gets the path to save server errors pages to
            location = this.net.errorPageLocation;
        end
        
        function this = setDefaultResolution(this,val)
            % This method sets the default resolution to use if a
            % resolution is not specified.  If it is empty and no
            % resolution is provided, an exception will occur
            validateattributes(val,{'numeric'},{'finite','nonnegative','integer','nonnan','real'});
            this.defaultResolution = val;
        end
        
        function this = setServerLocation(this,val)
            % Verify you can resolve server.
            try
                this.net.testUrl(val);
                %urlread(val);
            catch err2
                
                if strcmpi(err2.identifier,'MATLAB:Java:GenericException') == 1
                    rethrow(err2);
                end
                
                ex = MException('OCP:ServerConnFail','Failed to resolve server.  Check server url');
                throw(ex);
            end
            
            this.serverLocation = val;
        end
        
        function this = setImageToken(this,token)
            % This method sets the image database token to be used
            
            % Get DB Info
            this.imageInfo = this.queryDBInfo(token);
            
            this.imageToken = token;
            
        end
        function token = getImageToken(this)
            % This method gets the image database token to be used
            
            token = this.imageToken;
        end
        
        function this = setAnnoToken(this,token)
            % This method sets the annotation database token to be used
            % Get DB Info
            this.annoInfo = this.queryDBInfo(token);
            
            % Verify it is a writable DB
            if this.annoInfo.PROJECT.READONLY == 1
                warning('OCP:ReadOnlyAnno','The current Annotation DB Token is for a READ ONLY database.');
            end
            
            this.annoToken = token;
        end
        function token = getAnnoToken(this)
            % This method gets the anno database token to be used
            
            token = this.annoToken;
        end
        
        function this = setImageTokenFile(this,file)
            % This method loads a token file and sets the image token
            
            if ~exist('file','var')
                [filename, pathname, ~] = uigetfile( ...
                    {  '*.token','Token (*.token)'}, ...
                    'Pick a Token File', ...
                    'MultiSelect', 'off');
                
                if isequal(filename,0)
                    warning('OCP:FileSelectionCancel','No file was selected.  Token not opened.');
                    return;
                end
                
                file = fullfile(pathname,filename);
            end
            
            % Read file
            fid = fopen(file,'r');
            tline = fgetl(fid);
            fclose(fid);
            
            % Set Token
            this.setImageToken(tline);
        end
        
        function this = setAnnoTokenFile(this,file)
            % This method loads a token file and sets the anno token
            
            if ~exist('file','var')
                [filename, pathname, ~] = uigetfile( ...
                    {  '*.token','Token (*.token)'}, ...
                    'Pick a Token File', ...
                    'MultiSelect', 'off');
                
                if isequal(filename,0)
                    warning('OCP:FileSelectionCancel','No file was selected.  Token not opened.');
                    return;
                end
                
                file = fullfile(pathname,filename);
            end
            
            % Read file
            fid = fopen(file,'r');
            tline = fgetl(fid);
            fclose(fid);
            
            % Set Token
            this.setAnnoToken(tline);
        end
        
        function url = getLastUrl(this)
            % Method to retreive the last URL that was used.  Useful for
            % developers.
            url = this.lastUrl;
        end
        
        %% Methods - Query
        function response = query(this, qObj)
            % This method builds a query and executes it based on the
            % supplied queryObj
            
            if nargin ~= 2
                ex = MException('OCP:ArgError','Incorrect Number of Arguments');
                throw(ex);
            end
            
            
            % Based on Query Type get what yo need!
            switch qObj.type
                case eOCPQueryType.imageDense
                    % If resolution isn't set Set Default and warn.
                    if isempty(qObj.resolution)
                        if isempty(this.defaultResolution)
                            error('OCP:MissingDefaultResolution',...
                                'The provided query is missing the resolution property.  The default resolution has not been set in this OCP object.  Cannot Query Database.');
                        end
                        
                        qObj.setResolution(this.defaultResolution);    
                        warning('OCP:QueryResolutionEmpty',...
                            'Resolution empty in query.  Default value of %d used. Turn off "OCP:QueryResolutionEmpty" to suppress',this.defaultResolution);
                    end
                    
                    % If annoToken hasn't been set stop
                    if isempty(this.imageToken)
                        ex = MException('OCP:MissingImageToken',...
                            'You must specify the image database to read from by setting the "imageToken" property. ');
                        throw(ex);
                    end
                    
                    % Verify query
                    [tf msg] = qObj.validate(this.imageInfo);
                    if tf == 0
                        ex = MException('OCP:BadQuery',sprintf('Query Validation Failed: \n%s',msg));
                        throw(ex);
                    end
                    
                    % Build URL
                    url = this.buildCutoutUrl(qObj);
                    this.lastUrl = url;
                    % Query DB and get HDF5 File
                    hdfFile = OCPHdf(this.net.readCached(url),qObj);
                    % Convert to RAMONVolume
                    response = hdfFile.toRAMONVolume();
                    
                case eOCPQueryType.imageSlice
                    % If resolution isn't set Set Default and warn.
                    if isempty(qObj.resolution)
                        if isempty(this.defaultResolution)
                            error('OCP:MissingDefaultResolution',...
                                'The provided query is missing the resolution property.  The default resolution has not been set in this OCP object.  Cannot Query Database.');
                        end
                        
                        qObj.setResolution(this.defaultResolution);
                        warning('OCP:QueryResolutionEmpty',...
                            'Resolution empty in query.  Default value of %d used. Turn off "OCP:QueryResolutionEmpty" to suppress',this.defaultResolution);
                    end
                    
                    % If annoToken hasn't been set stop
                    if isempty(this.imageToken)
                        ex = MException('OCP:MissingImageToken',...
                            'You must specify the image database to read from by setting the "imageToken" property. ');
                        throw(ex);
                    end
                    
                    % Verify query
                    [tf msg] = qObj.validate(this.imageInfo);
                    if tf == 0
                        ex = MException('OCP:BadQuery',sprintf('Query Validation Failed: \n%s',msg));
                        throw(ex);
                    end
                    % Build URL
                    url = this.buildSliceUrl(qObj);
                    % Query DB and get png File back
                    response = this.net.queryImage(url);
                    
                    
                case eOCPQueryType.annoDense
                    % If resolution isn't set Set Default and warn.
                    if isempty(qObj.resolution)
                        if isempty(this.defaultResolution)
                            error('OCP:MissingDefaultResolution',...
                                'The provided query is missing the resolution property.  The default resolution has not been set in this OCP object.  Cannot Query Database.');
                        end
                        
                        qObj.setResolution(this.defaultResolution);
                        warning('OCP:QueryResolutionEmpty',...
                            'Resolution empty in query.  Default value of %d used. Turn off "OCP:QueryResolutionEmpty" to suppress',this.defaultResolution);
                    end
                    
                    % If annoToken hasn't been set stop
                    if isempty(this.annoToken)
                        ex = MException('OCP:MissingAnnoToken',...
                            'You must specify the annotation database to read from by setting the "annoToken" property. ');
                        throw(ex);
                    end
                    
                    % Verify query
                    [tf msg] = qObj.validate(this.annoInfo);
                    if tf == 0
                        ex = MException('OCP:BadQuery',sprintf('Query Validation Failed: \n%s',msg));
                        throw(ex);
                    end
                    % Build URL
                    url = this.buildCutoutUrl(qObj);
                    this.lastUrl = url;
                    % Query DB and get HDF5 File
                    hdfFile = OCPHdf(this.net.read(url),qObj);
                    % Convert to RAMONVolume
                    response = hdfFile.toRAMONVolume();
                    
                    
                case eOCPQueryType.annoSlice
                    % If resolution isn't set Set Default and warn.
                    if isempty(qObj.resolution)                        
                        if isempty(this.defaultResolution)
                            error('OCP:MissingDefaultResolution',...
                                'The provided query is missing the resolution property.  The default resolution has not been set in this OCP object.  Cannot Query Database.');
                        end
                        
                        qObj.setResolution(this.defaultResolution);
                        warning('OCP:QueryResolutionEmpty',...
                            'Resolution empty in query.  Default value of %d used. Turn off "OCP:QueryResolutionEmpty" to suppress',this.defaultResolution);
                    end
                    
                    % If annoToken hasn't been set stop
                    if isempty(this.annoToken)
                        ex = MException('OCP:MissingAnnoToken',...
                            'You must specify the annotation database to read from by setting the "annoToken" property. ');
                        throw(ex);
                    end
                    
                    % Verify query
                    [tf msg] = qObj.validate(this.annoInfo);
                    if tf == 0
                        ex = MException('OCP:BadQuery',sprintf('Query Validation Failed: \n%s',msg));
                        throw(ex);
                    end
                    % Build URL
                    url = this.buildSliceUrl(qObj);
                    this.lastUrl = url;
                    % Query DB and get png File back
                    response = this.net.queryImage(url);
                    
                case eOCPQueryType.overlaySlice
                    % If resolution isn't set Set Default and warn.
                    if isempty(qObj.resolution)
                        if isempty(this.defaultResolution)
                            error('OCP:MissingDefaultResolution',...
                                'The provided query is missing the resolution property.  The default resolution has not been set in this OCP object.  Cannot Query Database.');
                        end
                        
                        qObj.setResolution(this.defaultResolution);
                        warning('OCP:QueryResolutionEmpty',...
                            'Resolution empty in query.  Default value of %d used. Turn off "OCP:QueryResolutionEmpty" to suppress',this.defaultResolution);
                    end
                    
                    % If annoToken hasn't been set stop
                    if isempty(this.annoToken)
                        ex = MException('OCP:MissingAnnoToken',...
                            'You must specify the annotation database to read from by setting the "annoToken" property. ');
                        throw(ex);
                    end
                    
                    % Verify query
                    [tf msg] = qObj.validate(this.annoInfo);
                    if tf == 0
                        ex = MException('OCP:BadQuery',sprintf('Query Validation Failed: \n%s',msg));
                        throw(ex);
                    end
                    % Build URL
                    url = this.buildSliceUrl(qObj);
                    this.lastUrl = url;
                    % Query DB and get png File back
                    response = this.net.queryImage(url);
                    
                case {eOCPQueryType.RAMONDense,eOCPQueryType.RAMONVoxelList}
                    % If resolution isn't set Set Default and warn.
                    if isempty(qObj.resolution)
                        if isempty(this.defaultResolution)
                            error('OCP:MissingDefaultResolution',...
                                'The provided query is missing the resolution property.  The default resolution has not been set in this OCP object.  Cannot Query Database.');
                        end
                        
                        qObj.setResolution(this.defaultResolution);
                        warning('OCP:QueryResolutionEmpty',...
                            'Resolution empty in query.  Default value of %d used. Turn off "OCP:QueryResolutionEmpty" to suppress',this.defaultResolution);
                    end
                    
                    % If annoToken hasn't been set stop
                    if isempty(this.annoToken)
                        ex = MException('OCP:MissingAnnoToken',...
                            'You must specify the annotation database to read from by setting the "annoToken" property. ');
                        throw(ex);
                    end
                    
                    % Verify query
                    [tf msg] = qObj.validate(this.annoInfo);
                    if tf == 0
                        ex = MException('OCP:BadQuery',sprintf('Query Validation Failed: \n%s',msg));
                        throw(ex);
                    end
                    % Build URL
                    url = this.buildRAMONUrl(qObj);
                    this.lastUrl = url;
                    % Query DB and get HDF5 File
                    hdfFile = OCPHdf(this.net.read(url));
                    % Convert to RAMON Object based on what comes back
                    response = hdfFile.toRAMONObject(qObj);
                    
                case eOCPQueryType.RAMONMetaOnly
                    % Verify query
                    [tf msg] = qObj.validate(this.annoInfo);
                    if tf == 0
                        ex = MException('OCP:BadQuery',sprintf('Query Validation Failed: \n%s',msg));
                        throw(ex);
                    end
                    
                    % If annoToken hasn't been set stop
                    if isempty(this.annoToken)
                        ex = MException('OCP:MissingAnnoToken',...
                            'You must specify the annotation database to read from by setting the "annoToken" property. ');
                        throw(ex);
                    end
                    
                    % Build URL
                    url = this.buildRAMONUrl(qObj);
                    this.lastUrl = url;
                    % Query DB and get HDF5 File
                    hdfFile = OCPHdf(this.net.read(url));
                    % Convert to RAMON Object based on what comes back
                    response = hdfFile.toRAMONObject(qObj);
                    
                    
                case eOCPQueryType.RAMONBoundingBox
                    % If resolution isn't set Set Default and warn.
                    if isempty(qObj.resolution)
                        if isempty(this.defaultResolution)
                            error('OCP:MissingDefaultResolution',...
                                'The provided query is missing the resolution property.  The default resolution has not been set in this OCP object.  Cannot Query Database.');
                        end
                        
                        qObj.setResolution(this.defaultResolution);
                        warning('OCP:QueryResolutionEmpty',...
                            'Resolution empty in query.  Default value of %d used. Turn off "OCP:QueryResolutionEmpty" to suppress',this.defaultResolution);
                    end
                    
                    % If annoToken hasn't been set stop
                    if isempty(this.annoToken)
                        ex = MException('OCP:MissingAnnoToken',...
                            'You must specify the annotation database to read from by setting the "annoToken" property. ');
                        throw(ex);
                    end
                    
                    % Verify query
                    [tf msg] = qObj.validate(this.annoInfo);
                    if tf == 0
                        ex = MException('OCP:BadQuery',sprintf('Query Validation Failed: \n%s',msg));
                        throw(ex);
                    end
                    
                    % Build URL
                    url = this.buildRAMONUrl(qObj);
                    this.lastUrl = url;
                    % Query DB and get HDF5 File
                    hdfFile = OCPHdf(this.net.read(url));
                    % Convert to RAMON Object based on what comes back
                    response = hdfFile.toRAMONObject(qObj);
                    
                    
                case eOCPQueryType.RAMONIdList
                    
                    % If doing a cutout and resolution isn't set Set Default and warn.
                    if ~isempty(qObj.xRange) && ~isempty(qObj.yRange) && ~isempty(qObj.zRange)
                        if isempty(qObj.resolution)                            
                            if isempty(this.defaultResolution)
                                error('OCP:MissingDefaultResolution',...
                                    'The provided query is missing the resolution property.  The default resolution has not been set in this OCP object.  Cannot Query Database.');
                            end

                            qObj.setResolution(this.defaultResolution);
                            warning('OCP:QueryResolutionEmpty',...
                                'Resolution empty in query.  Default value of %d used. Turn off "OCP:QueryResolutionEmpty" to suppress',this.defaultResolution);
                        end
                    end
                    
                    % If annoToken hasn't been set stop
                    if isempty(this.annoToken)
                        ex = MException('OCP:MissingAnnoToken',...
                            'You must specify the annotation database to read from by setting the "annoToken" property. ');
                        throw(ex);
                    end
                    
                    % Verify query
                    [tf msg] = qObj.validate(this.annoInfo);
                    if tf == 0
                        ex = MException('OCP:BadQuery',sprintf('Query Validation Failed: \n%s',msg));
                        throw(ex);
                    end
                    % Build URL
                    url = this.buildRAMONIdUrl(qObj);
                    this.lastUrl = url;
                    
                    % Build HDF5 if needed
                    if isempty(qObj.xRange) && isempty(qObj.yRange) && isempty(qObj.zRange)
                        % no cutout restriction
                        % Query DB and get HDF5 File
                        hdfFile = OCPHdf(this.net.read(url));
                        
                    elseif ~isempty(qObj.xRange) && ~isempty(qObj.yRange)...
                            && ~isempty(qObj.zRange) && ~isempty(qObj.resolution)
                        % cutout Restriction
                        hdfCutoutFile = OCPHdf(qObj);
                        hdfCutoutFile.toCutoutHDF();
                        
                        % Query DB and get HDF5 File
                        hdfFile = OCPHdf(this.net.read(url,hdfCutoutFile.filename));
                        
                    else
                        ex = MException('OCP:MalformedQuery','Cannot build URL.  Either set or clear cutout args.');
                        throw(ex);
                    end
                    
                    % Convert to a vector
                    response = hdfFile.toMatrix();
                    
                case eOCPQueryType.voxelId
                    % If resolution isn't set Set Default and warn.
                    if isempty(qObj.resolution)
                        if isempty(this.defaultResolution)
                            error('OCP:MissingDefaultResolution',...
                                'The provided query is missing the resolution property.  The default resolution has not been set in this OCP object.  Cannot Query Database.');
                        end
                        
                        qObj.setResolution(this.defaultResolution);
                        warning('OCP:QueryResolutionEmpty',...
                            'Resolution empty in query.  Default value of %d used. Turn off "OCP:QueryResolutionEmpty" to suppress',this.defaultResolution);
                    end
                    
                    % Verify query
                    [tf msg] = qObj.validate(this.annoInfo);
                    if tf == 0
                        ex = MException('OCP:BadQuery',sprintf('Query Validation Failed: \n%s',msg));
                        throw(ex);
                    end
                    
                    % If annoToken hasn't been set stop
                    if isempty(this.annoToken)
                        ex = MException('OCP:MissingAnnoToken',...
                            'You must specify the annotation database to read from by setting the "annoToken" property. ');
                        throw(ex);
                    end
                    
                    % Build URL
                    url = this.buildXyzVoxelIdUrl(qObj);
                    this.lastUrl = url;
                    
                    % Query
                    hdfResponse = OCPHdf(this.net.read(url));
                    response = str2double(hdfResponse.filename);
                    
                otherwise
                    ex = MException('OCP:InvalidQuery','Invalid Query Type');
                    throw(ex);
            end
            
            % Save query
            this.lastQuery = qObj;
        end
        
        %% Methods - Single slice
        function slice = nextSlice(this)
            % This method increments cIndex by 1 and returns an image
            % The last query MUST have been a slice query for this to work
            slice = [];
            qObj = this.lastQuery;
            
            if ~isempty(qObj)
                if qObj.type == eOCPQueryType.annoSlice || ...
                        qObj.type == eOCPQueryType.imageSlice || ...
                        qObj.type == eOCPQueryType.overlaySlice
                    % You are good to go
                    
                    % Verify query
                    qObj.setCIndex(qObj.cIndex + 1);
                    [tf msg] = qObj.validate(this.annoInfo);
                    if tf == 0
                        ex = MException('OCP:BadQuery',sprintf('Query Validation Failed: \n%s',msg));
                        throw(ex);
                    end
                    % Build URL
                    url = this.buildSliceUrl(qObj);
                    this.lastUrl = url;
                    % Query DB and get png File back
                    slice = this.net.queryImage(url);
                else
                    warning('OCP:MissingInitQuery','You must run a full slice query before using next/previous methods.');
                end
            else
                warning('OCP:MissingInitQuery','You must run a full slice query before using next/previous methods.');
            end
        end
        
        
        function slice = previousSlice(this)
            % This method decrements cIndex by 1 and returns an image
            % The last query MUST have been a slice query for this to work
            slice = [];
            qObj = this.lastQuery;
            
            if ~isempty(qObj)
                if qObj.type == eOCPQueryType.annoSlice || ...
                        qObj.type == eOCPQueryType.imageSlice || ...
                        qObj.type == eOCPQueryType.overlaySlice
                    % You are good to go
                    
                    % Verify query
                    qObj.setCIndex(qObj.cIndex - 1);
                    [tf msg] = qObj.validate(this.annoInfo);
                    if tf == 0
                        ex = MException('OCP:BadQuery',sprintf('Query Validation Failed: \n%s',msg));
                        throw(ex);
                    end
                    % Build URL
                    url = this.buildSliceUrl(qObj);
                    this.lastUrl = url;
                    % Query DB and get png File back
                    slice = this.net.queryImage(url);
                else
                    warning('OCP:MissingInitQuery','You must run a full slice query before using next/previous methods.');
                end
            else
                warning('OCP:MissingInitQuery','You must run a full slice query before using next/previous methods.');
            end
        end
        
        %% Methods - RAMON - Create
        function id = createAnnotation(this, ramonObj, conflictOption)
            % This method adds a new RAMON annotation to the database
            % specified by annoToken.
            %
            % It supports the batch interface by passing in a cell array of
            % RAMON objects instead of a single RAMON Object.
            %
            % You can also optionally specify the conflict option
            % (overwrite, preserve, exception) by passing in your choice
            % via the eOCPConflictOption enum. If omitted default is overwrite.
            %
            % ex: id = createAnnotation(myObjects,eOCPConflicOption.overwrite);
            %
            
            % Set default conflict option default (overwrite) if needed
            if ~exist('conflictOption','var')
                conflictOption = eOCPConflictOption.overwrite;
            end
                      
            % If annoToken hasn't been set stop
            if isempty(this.annoToken)
                ex = MException('OCP:MissingAnnoToken',...
                    'You must specify the annotation database to write to by setting the "annoToken" property. ');
                throw(ex);
            end
            
            % Build upload job based on input.  If a cell array of
            % RAMONObjects then you must build batches based on
            % this.batchSize.  If any annotation is larger than
            % this.maxAnnoSize then it must be broken up into pieces to
            % make http requests resonable in size and safe to pass through most
            % networks without trouble
            
            if isa(ramonObj,'cell')
                % Batch upload requested - build batch index while checking
                % for big annotations that need chunked
                [batchIndex, chunkIndex] = this.createAnnoBatches(ramonObj);
                                
                % Upload Batches
                batchIds = [];
                for ii = 1:size(batchIndex,1)
                    batchIds = cat(2,batchIds,...
                        this.writeRamonObject(ramonObj(batchIndex{ii}),false,conflictOption));
                end
                
                % If required chunk annotations and upload
                chunkIds = [];
                if ~isempty(chunkIndex)
                    chunkCollections = this.createAnnoChunks(ramonObj(chunkIndex));
                                        
                    chunkIds = this.writeRamonChunks(chunkCollections,false,conflictOption);                    
                end
                
                % Finalize output
                id = zeros(1,length(batchIds) + length(chunkIds));
                batchIndexCat = [];
                for ii = 1:size(batchIndex,1)
                    batchIndexCat = cat(2,batchIndexCat,batchIndex{ii});
                end
                id(batchIndexCat) = batchIds;
                id(chunkIndex) = chunkIds;                
            else
                % Check for chunking
                if ramonObj.voxelCount() > this.maxAnnoSize
                    % Chunk it up                    
                    chunkCollection = this.createAnnoChunks(ramonObj);
                    
                    % Upload the chunked annotation
                    id = this.writeRamonChunks(chunkCollection,false,conflictOption);
                else                    
                    % Single annotation to upload
                    id = this.writeRamonObject(ramonObj, false, conflictOption);                    
                end
            end
        end
        
        %% Methods - RAMON - Update
        function id = updateAnnotation(this, ramonObj, conflictOption)            
            % This method updates a RAMON annotation to the database
            % specified by annoToken.
            %
            % It supports the batch interface by passing in a cell array of
            % RAMON objects instead of a single RAMON Object.
            %
            % You can also optionally specify the conflict option
            % (overwrite, preserve, exception) by passing in your choice
            % via the eOCPConflictOption enum. If omitted default is overwrite.
            %
            
            % Set default conflict option default (overwrite) if needed
            if ~exist('conflictOption','var')
                conflictOption = eOCPConflictOption.overwrite;
            end
                      
            % If annoToken hasn't been set stop
            if isempty(this.annoToken)
                ex = MException('OCP:MissingAnnoToken',...
                    'You must specify the annotation database to write to by setting the "annoToken" property. ');
                throw(ex);
            end            
            
            % Build upload job based on input.  If a cell array of
            % RAMONObjects then you must build batches based on
            % this.batchSize.  If any annotation is larger than
            % this.maxAnnoSize then it must be broken up into pieces to
            % make http requests resonable in size and safe to pass through most
            % networks without trouble
            
            if isa(ramonObj,'cell')
                % Batch upload requested - build batch index while checking
                % for big annotations that need chunked
                [batchIndex, chunkIndex] = this.createAnnoBatches(ramonObj);
                                
                % Upload Batches
                batchIds = [];
                for ii = 1:size(batchIndex,1)
                    batchIds = cat(2,batchIds,...
                        this.writeRamonObject(ramonObj(batchIndex{ii}),true,conflictOption));
                end
                
                % If required chunk annotations and upload
                chunkIds = [];
                if ~isempty(chunkIndex)
                    chunkCollections = this.createAnnoChunks(ramonObj(chunkIndex));
                    
                    for ii = 1:size(chunkCollections)
                        chunkIds = cat(2, chunkIds,...
                            this.writeRamonChunks(chunkCollections,true,conflictOption));
                    end
                end
                
                % Finalize output
                id = cat(2,batchIds,chunkIds);
                
            else
                % Check for chunking
                if ramonObj.voxelCount() > this.maxAnnoSize
                    % Chunk it up                    
                    chunkCollection = this.createAnnoChunks(ramonObj);
                    
                    % Upload the chunked annotation
                    id = this.writeRamonChunks(chunkCollection,true,conflictOption);
                else                    
                    % Single annotation to upload
                    id = this.writeRamonObject(ramonObj, true, conflictOption);                    
                end
            end
        end
        
        %% Methods - RAMON - Delete
        function response = deleteAnnotation(this, id)
            % This method deletes an exisiting RAMON Annotation in the
            % database specified by annotationToken and id
            
            % If annoToken hasn't been set stop
            if isempty(this.annoToken)
                ex = MException('OCP:MissingAnnoToken',...
                    'You must specify the annotation database to write to by setting the "annoToken" property. ');
                throw(ex);
            end
            
            % If in batch mode build id string
            if length(id) > 1
                idStr = sprintf('%d,',id);
                idStr(end) = [];
            else
                idStr = sprintf('%d',id);
            end
            
            % Send DELETE request
            urlStr = sprintf('%s/emca/%s/%s/',this.serverLocation,this.annoToken,idStr);
            this.lastUrl = urlStr;
            response = this.net.deleteRequest(urlStr);
        end
        
        %% Methods - RAMON - Get/Set
        function setField(this, id, field, value)
            % This method sets an individual field of an annotation based
            % on the provided annotation id and field name and value.  Use OCPFields
            % to get the proper translation from RAMON api names to server.
            % 
            % NOTE: Only single value fields are currently supported
            %
            % ex: f = OCPFields;
            %     val = oo.setField(2834,f.synapse.synapseType,eRAMONSynapseType.excitatory);
            %     val = oo.getField(2834,'author','my_username');
            
            % Build URL
            url = this.buildSetFieldURL(id,field,value);
            this.lastUrl = url;            
            
            % Call URL
            this.net.read(url);   
        end
        
        
        function value = getField(this, id, field)
            % This method gets an individual field from an annotation based
            % on the provided annotation id and field name.  Use OCPFields
            % to get the proper translation from RAMON api names to server
            % names.
            % ex: f = OCPFields;
            %     val = oo.getField(2834,f.synapse.synapseType);
            %     val = oo.getField(2834,'author');
            
            % Build URL
            url = sprintf('%s/emca/%s/%d/getField/%s/',this.serverLocation,this.annoToken,id,field);
            this.lastUrl = url;            
            
            % Call URL
            response = this.net.read(url);
            
            % Parse response
            value = this.getFieldParser(response,field);
        end
        
        
        %% Methods - Database Info Query
        function info = queryDBInfo(this,token)
            % This method queries the "projinfo" service with a token and
            % returns information about that database.  The return
            % structure is:
            %
            % TODO: document
            
            url = sprintf('%s/emca/%s/projinfo/',this.serverLocation,token);
            this.lastUrl = url;
            
            % Query DB for hdf5 file
            hdfFile = this.net.read(url);
            
            % Load into struct
            ocpH5 = OCPHdf(hdfFile);
            info = ocpH5.toStruct();
        end
        
        
    end
    
    methods( Access = private )
        
        %% Private Method - calculate batches based on settings and annotation size
        function [batchIndex, chunkIndex] = createAnnoBatches(this, ramonObj)
            % This method creates an index that breaks the ramonObj cell
            % array into batches for upload based on both number of
            % annotation and voxel size of annotations
            
            objectIndex = 1:length(ramonObj);
            
            % Check for objects that require chunking
            count = cellfun(@(x) x.voxelCount,ramonObj);
            chunkIndex = find(count > this.maxAnnoSize);
            objectIndex(chunkIndex) = [];
            
            % Build batches
            numObj = length(objectIndex);
            numGroups = floor(numObj / this.batchSize);
            remainGroup = mod(numObj,this.batchSize);
            
            if remainGroup ~= 0
                batchIndex = cell(numGroups + 1, 1);
            else
                batchIndex = cell(numGroups, 1);
            end
            
            startInd = 1;
            for ii = 1:numGroups
                batchIndex(ii) = {objectIndex(startInd:startInd + this.batchSize - 1)};
                startInd = startInd + this.batchSize;
            end
            
            if remainGroup ~= 0
                batchIndex(numGroups + 1) = {objectIndex(startInd:numObj)};
            end                       
        end
        
        %% Private Method - inforce max annotation size with chunking
        function chunkCollections = createAnnoChunks(this, ramonObj)
            % This method enforces max annotation size by breaking the
            % annotation into chunks that can be uploaded
            
            if length(ramonObj) == 1
                ramonObj = {ramonObj};   
                chunkCollections = cell(1,1);
            else                
                chunkCollections = cell(1,length(ramonObj));
            end
            
            for ii = 1:length(ramonObj)
               clear chunkGroup
               
               % Convert to voxel list
               annoVoxelList = ramonObj{ii}.clone;
               annoVoxelList.toVoxelList();
               
               % Create update objects
               voxCount = annoVoxelList.voxelCount();
               numChunks = floor(voxCount / this.maxAnnoSize);
               remainChunk = mod(voxCount,this.maxAnnoSize);
               
               % Create empty initial annotation
               template = annoVoxelList.clone('novoxels');
               template.setVoxelList([]);
               if remainChunk ~= 0
                   chunkGroup = cell(1,numChunks + 2);
               else
                   chunkGroup = cell(1,numChunks + 1);
               end
               chunkGroup{1} = template;
               
               % Create chunks
               startInd = 1;
               if numChunks ~= 0
                   for jj = 2:numChunks+1
                       tempObj = template.clone('novoxels');
                       tempObj.setVoxelList(annoVoxelList.data(startInd:startInd+this.maxAnnoSize-1,:));
                       startInd = startInd+this.maxAnnoSize;
                       chunkGroup{jj} = tempObj;
                   end
               end
               
               if remainChunk ~= 0
                   tempObj = template.clone('novoxels');
                   tempObj.setVoxelList(annoVoxelList.data(startInd:voxCount,:));
                   chunkGroup{end} = tempObj;                   
               end    
               
               % Store group into collection
               chunkCollections{ii} = chunkGroup;
            end
        end
        
        %% Private Method - write annotation chunks to database
        function id = writeRamonChunks(this, chunkCollection, updateFlag, conflictOption)
            % This method writes a chunked ramon object by creating an
            % annotation without voxel data first and then updating it
            % repeatedly with the chunked voxel data in list form.
            %
            % updateFlag is an optional boolean indicating if you want to
            % upload the annotation as an update instead of a create.
            % It is false by default (create new annotation)
            
            if ~exist('updateFlag','var') 
                updateFlag = false;
            end
            
            id = [];
            for ii = 1:length(chunkCollection)
                chunkGroup = chunkCollection{ii};
                
                if updateFlag == false
                    % Write empty anno and get ID
                    id = cat(2,id,...
                        this.writeRamonObject(chunkGroup{1}, 0, conflictOption));    
                else
                    % You are doing a big update so first write is an
                    % update as well
                    id = cat(2,id,...
                        this.writeRamonObject(chunkGroup{1}, 1, conflictOption));   
                end
            
                % Set the ID and update with all voxel chunks
                for jj = 2:length(chunkGroup)
                    chunkGroup{jj}.setId(id(end));
                	this.writeRamonObject(chunkGroup{jj}, 1, conflictOption);
                end
            end
        end
        
        %% Private Method - write annotation to database
        function id = writeRamonObject(this, ramonObj, updateFlag, conflictOption)
            % This method writes a ramon object to the specified database
            % Also supports batch interface so ramonObj can be a cell array.
            %
            % updateFlag is an optional boolean indicating if you want to
            % upload the annotation as an update instead of a create.
            % If true all objects must have an ID already assigned
            
            % If updateFlag is true, enforce ID requirement
            if exist('updateFlag','var') 
                if updateFlag == true
                    if isa(ramonObj,'cell')
                        % Batch Upload
                        ind = cellfun(@(x) isprop(x,'id'),ramonObj);
                        ind1 = cellfun(@(x) isempty(x.id),ramonObj(ind));
                        ind2 = cellfun(@(x) x.id == 0,ramonObj(ind));

                        if sum(ind1) > 0 || sum(ind2) > 0                   
                            error('OCP:IdMissing',...
                                'If uploading annotations with the updateFlag = true you must set the ID field in each object first so the correct annotation can be updated!');
                        end                
                    else
                        % Single object
                        if isempty(ramonObj.id) || ramonObj.id == 0                            
                            error('OCP:IdMissing',...
                                'If uploading annotations with the updateFlag = true you must set the ID field in each object first so the correct annotation can be updated!');
                        end                
                    end  
                end
            else
                updateFlag = false;
            end

            
            % If resolution isn't set Set Default and warn.
            if isa(ramonObj,'cell')
                % Batch Upload
                
                ind = cellfun(@(x) isprop(x,'resolution'),ramonObj);
                ind = cellfun(@isempty,ramonObj(ind));
                
                if sum(ind) > 0                                               
                    if isempty(this.defaultResolution)
                        error('OCP:MissingDefaultResolution',...
                            'The provided RAMON Object''s resolution property is empty AND the default resolution in this OCP object is empty.  One of these is required to complete operation.');
                    end
                            
                    cellfun(@(x) x.setResolution(this.defaultResolution),ramonObj(ind))
                    warning('OCP:RAMONResolutionEmpty',...
                        'Resolution empty in RAMON Object.  Default value of %d used. Turn off "OCP:RAMONResolutionEmpty" to suppress',this.defaultResolution);
                end                
            else
                % Single object
                
                if isprop(ramonObj,'resolution')
                    if isempty(ramonObj.resolution)                           
                        if isempty(this.defaultResolution)
                            error('OCP:MissingDefaultResolution',...
                            'The provided RAMON Object''s resolution property is empty AND the default resolution in this OCP object is empty.  One of these is required to complete operation.');
                        end
                        ramonObj.setResolution(this.defaultResolution);
                        warning('OCP:RAMONResolutionEmpty',...
                            'Resolution empty in RAMON Object.  Default value of %d used. Turn off "OCP:RAMONResolutionEmpty" to suppress',this.defaultResolution);
                    end
                end                
            end        
                  
            % Create HDF5 file
            hdfFile = OCPHdf(ramonObj);
                    
            % Build URL
            if updateFlag == false
                % Create Annotation
                urlStr = sprintf('%s/emca/%s/%s/',...
                    this.serverLocation,...
                    this.annoToken,...
                    char(conflictOption));
            else
                % Update Annotation                
                urlStr = sprintf('%s/emca/%s/update/%s/',...
                    this.serverLocation,...
                    this.annoToken,...
                    char(conflictOption));            
            end 
            this.lastUrl = urlStr;
            
            % Post HDF file to database with retry on failure
            cnt = 1;
            while cnt <= 3
                try
                    id = this.net.write(urlStr,hdfFile.filename);
                    break;
                    
                catch ME
                    if cnt == 3
                        rethrow(ME);
                    end
                    warning('OCP:BatchWriteError','DB Write Op Failed. Attempting RETRY: %d\nError: %s',cnt,ME.message);
                    cnt = cnt + 1;
                    pause(2);
                end
            end
                    
            if isa(ramonObj,'cell')
                % Batch Upload                
                id = eval(['[' id ']']);                
            else
                % Single object                   
                id = str2double(id);
            end
        end
        
        %% Private Method - Build URL - Cutout
        function url = buildCutoutUrl(this, qObj)
            % This method build the url for a cutout type query.  It
            % selects the correct service and token automatically.
            switch qObj.type
                case eOCPQueryType.imageDense
                    service = 'emca';
                    token = this.imageToken;
                case eOCPQueryType.annoDense
                    service = 'emca';
                    token = this.annoToken;
                otherwise
                    ex = MException('OCP:NotCutout','Query is not a cutout type.  Cannot build url.');
                    throw(ex);
            end
            

            % no filter 
            url = sprintf('%s/%s/%s/hdf5/%d/%d,%d/%d,%d/%d,%d/',...
                            this.serverLocation,...
                            service,...
                            token,...
                            qObj.resolution,...
                            qObj.xRange(1),qObj.xRange(2),...
                            qObj.yRange(1),qObj.yRange(2),...
                            qObj.zRange(1),qObj.zRange(2));
            
             if ~isempty(qObj.filterIds)                
                % add filter option
                ids2filter = sprintf('%d,',qObj.filterIds);
                ids2filter(end) = [];
                url = sprintf('%sfilter/%s/',...
                                url,...
                                ids2filter);
                
            end
            
            
        end
        
        %% Private Method - Build URL - Slice
        function url = buildSliceUrl(this, qObj)
            % This method build the url for a slice type query.  It
            % selects the correct service and token automatically.
            switch qObj.type
                case eOCPQueryType.imageSlice
                    service = 'emca';
                    token = this.imageToken;
                case eOCPQueryType.annoSlice
                    service = 'emca';
                    token = this.annoToken;
                case eOCPQueryType.overlaySlice
                    service = 'overlay';
                    token = this.annoToken;
                otherwise
                    ex = MException('OCP:NotSlice','Query is not a slice type.  Cannot build url.');
                    throw(ex);
            end
            
            switch qObj.slicePlane
                case eOCPSlicePlane.xy
                    url = sprintf('%s/%s/%s/%s/%d/%d,%d/%d,%d/%d/',...
                        this.serverLocation,...
                        service,...
                        token,...
                        char(qObj.slicePlane),...
                        qObj.resolution,...
                        qObj.aRange(1),qObj.aRange(2),...
                        qObj.bRange(1),qObj.bRange(2),...
                        qObj.cIndex(1));
                    
                case eOCPSlicePlane.xz
                    url = sprintf('%s/%s/%s/%s/%d/%d,%d/%d/%d,%d/',...
                        this.serverLocation,...
                        service,...
                        token,...
                        char(qObj.slicePlane),...
                        qObj.resolution,...
                        qObj.aRange(1),qObj.aRange(2),...
                        qObj.cIndex(1),...
                        qObj.bRange(1),qObj.bRange(2));
                    
                case eOCPSlicePlane.yz
                    url = sprintf('%s/%s/%s/%s/%d/%d/%d,%d/%d,%d/',...
                        this.serverLocation,...
                        service,...
                        token,...
                        char(qObj.slicePlane),...
                        qObj.resolution,...
                        qObj.cIndex(1),...
                        qObj.aRange(1),qObj.aRange(2),...
                        qObj.bRange(1),qObj.bRange(2));
            end
            
             if ~isempty(qObj.filterIds)                
                % add filter option
                ids2filter = sprintf('%d,',qObj.filterIds);
                ids2filter(end) = [];
                url = sprintf('%sfilter/%s/',...
                                url,...
                                ids2filter);
                
            end
        end
        
        %% Private Method - Build URL - RAMON
        function url = buildRAMONUrl(this,qObj)
            % This method build the url for a RAMON object query.  It
            % selects the correct service and token automatically.
            switch qObj.type
                case eOCPQueryType.RAMONDense
                    option = 'cutout';
                    token = this.annoToken;
                case eOCPQueryType.RAMONVoxelList
                    option = 'voxels';
                    token = this.annoToken;
                case eOCPQueryType.RAMONMetaOnly
                    option = 'nodata';
                    token = this.annoToken;
                case eOCPQueryType.RAMONBoundingBox
                    option = 'boundingbox';
                    token = this.annoToken;
                otherwise
                    ex = MException('OCP:NotRAMON','Query is not a RAMON type.  Cannot build url.');
                    throw(ex);
            end
            
            % If batch mode you need to send csv list of ids in url
            if length(qObj.id) > 1
                idStr = sprintf('%d,',qObj.id);
                idStr(end) = [];
            else
                idStr = sprintf('%d',qObj.id);
            end
            
            % If just tacking on the resolution add to URL
            % If doing a cutout add all cutout args
            % Otherwise don't mess with url
            if ~isempty(qObj.resolution) && ...
                    isempty(qObj.xRange) && ...
                    isempty(qObj.yRange) && ...
                    isempty(qObj.zRange)
                % Add resolution
                url = sprintf('%s/emca/%s/%s/%s/%d/',...
                    this.serverLocation,...
                    token,...
                    idStr,...
                    option,...
                    qObj.resolution);
            elseif  ~isempty(qObj.resolution) && ...
                    ~isempty(qObj.xRange) && ...
                    ~isempty(qObj.yRange) && ...
                    ~isempty(qObj.zRange)
                % Add resolution
                url = sprintf('%s/emca/%s/%s/%s/%d/%d,%d/%d,%d/%d,%d/',...
                    this.serverLocation,...
                    token,...
                    idStr,...
                    option,...
                    qObj.resolution,...
                    qObj.xRange(1),qObj.xRange(2),...
                    qObj.yRange(1),qObj.yRange(2),...
                    qObj.zRange(1),qObj.zRange(2));
            else
                % Don't
                url = sprintf('%s/emca/%s/%s/%s/',...
                    this.serverLocation,...
                    token,...
                    idStr,...
                    option);
            end
        end
        
        %% Private Method - Build URL - RAMON Id List
        function url = buildRAMONIdUrl(this,qObj)
            % This method build the url for an RAMON object id predicate
            % query
            
            if ~isempty(qObj.idListPredicates)
                % Build predicate string
                predicateStr = '';
                keys = qObj.idListPredicates.keys;
                for ii = 1:qObj.idListPredicates.Count
                    switch keys{ii}
                        case char(eOCPPredicate.status)                            
                            predicateStr = sprintf('%s%s/%d/',predicateStr,...
                                keys{ii},uint32(qObj.idListPredicates(keys{ii})));

                        case char(eOCPPredicate.type)
                            predicateStr = sprintf('%s%s/%d/',predicateStr,...
                                keys{ii},uint32(qObj.idListPredicates(keys{ii})));
                            
                        case char(eOCPPredicate.confidence_gt)
                            predicateStr = sprintf('%s/confidence/gt/%f/',predicateStr,...
                                qObj.idListPredicates(keys{ii}));
                            
                        case char(eOCPPredicate.confidence_lt)
                            predicateStr = sprintf('%s/confidence/lt/%f/',predicateStr,...
                                qObj.idListPredicates(keys{ii}));
                            
                        otherwise
                            error('OCP:buildRAMONIdUrl','Unsupported predicate: %s',keys{ii});                            
                    end
                end
                
                % build url
                url = sprintf('%s/emca/%s/query/%s',...
                    this.serverLocation,...
                    this.annoToken,...
                    predicateStr);
            else
                % no predicates listed so get ids of everything
                url = sprintf('%s/emca/%s/query/',...
                    this.serverLocation,...
                    this.annoToken);
            end
            
            % if there is a list limit supplied append it to the URL
            if ~isempty(qObj.idListLimit)
                url = sprintf('%slimit/%d/',url,qObj.idListLimit);                
            end
            
        end
        
        %% Private Method - Build URL - XYZ Voxel ID
        function url = buildXyzVoxelIdUrl(this,qObj)
            % This method build the url for an xyz voxel id query
            
            % Set resolution to default if it isn't set
            if isempty(qObj.resolution)
                qObj.setResolution(this.defaultResolution);
            end
            
            url = sprintf('%s/emca/%s/id/%d/%d/%d/%d/',...
                this.serverLocation,...
                this.getAnnoToken(),...
                qObj.resolution,...
                qObj.xyzCoord(1),...
                qObj.xyzCoord(2),...
                qObj.xyzCoord(3));
            
        end
        
        
        %% Private Method - Build setField URL
        
        function url = buildSetFieldURL(this, id, field, value)
            % This method builds a REST URL to set a field of an existing
            % annotation
            
            % Handle field value difference and convert to string
            switch field
                case 'author'
                    strVal = value;
                    
                case {'status','synapse_type','segmentclass','cubelocation',...
                        'organelleclass'}
                    strVal = num2str(uint32(value));
                    
                case {'confidence','weight','neuron','parentseed','source','parent'}
                    strVal = num2str(value);
                    
                case {'seeds','position','synapses','organelles','segments'}
                    strVal = sprintf('%d,',value);
                    strVal(end) = [];                    
                    
                otherwise
                    % Assume you're adding a custom KV pair
                    if ~ischar(field)
                        error('OCP:InvalidCustomKey','Custom Keys must be char strings');
                    end                        
                    warning('OCP:CustomKVPair','Adding a custom KV pair - Key: %s',field);
                    
                    % Convert value into a string that will eval to what it
                    % should be
                    if isnumeric(value)
                        % String-ify so it will eval() back to a numeric
                        strVal = mat2str(value);
                        strVal = strrep(strVal,' ',',');
                    elseif ischar(value)
                        value = strrep(value,' ','_');
                        strVal = value;
                    else                        
                        error('OCP:InvalidValueClass','Custom Values must be numeric or char strings.  Class: %s',class(value));
                    end
                       
            end
                 
            % Build URL
            url = sprintf('%s/emca/%s/%d/setField/%s/%s/',...
                this.serverLocation,this.annoToken,id,field,strVal);
            
            
        end
        
        %% Private Method - getField interface response parser
        function value = getFieldParser(this, response, field)
            % parse the string response from the get interface and make the
            % appropriate type.
            switch field
                case {'author'}
                    value = response;
                    
                case 'status'
                    value = eRAMONAnnoStatus(str2double(response));
                                        
                case {'confidence','weight','neuron',...
                        'parentseed','source','parent'}
                    value = str2double(response);
                    
                case 'synapse_type'
                    value = eRAMONSynapseType(str2double(response));
                    
                case 'segmentclass'
                    value = eRAMONSegmentClass(str2double(response));
                
                case 'organelleclass'
                    value = eRAMONOrganelleClass(str2double(response));
                
                case 'cubelocation'
                    value = eRAMONCubeOrientation(str2double(response));
                
                case 'segments'
                    if ~isempty(strfind(response,'],['))
                        modStr = strrep(response,'],[','];[');
                        value = eval(['[' modStr ']']);
                    else
                        value = eval(['[' response ']']);
                    end
                
                case {'seeds','synapses','organelles','position'}
                    value = eval(['[' response ']']);
                    
                otherwise
                    % Assume custom KVPair
                    % Eval to make sure numerics go back to numerics
                    try
                        value = eval(response);
                    catch ME %#ok<NASGU>
                        value = response;
                    end                       
                    
            end
            
        end
    end
end

