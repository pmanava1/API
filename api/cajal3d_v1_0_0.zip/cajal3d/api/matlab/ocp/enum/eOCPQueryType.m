classdef eOCPQueryType < uint32
    %eRequests Enumeration of server request types
    % imageDense - Dense Image DB Cutout
    % imageSlice - Single Slice of Image DB
    % annoDense - Dense Annotation DB Cutout
    % annoSlice - Single Slice of Annotation DB
    % overlaySlice - Single Slice of Overlay of image and annotation DBs
    % RAMONDense - RAMON object query with voxel data in Dense Format
    % RAMONVoxelList - RAMON object query with voxel data in Voxel List Format
    % RAMONMetaOnly - RAMON object query with NO voxel data returned
    % RAMONBoundingBox - Returns a cuboid aligned bounding box around RAMON Object
    % RAMONIdList - Query to search annotation database by setting
    %               RAMON object metadata predicates.  Can be restricted to
    %               a cutout by setting Cutout Args.  By default searches
    %               whole DB if X, Y, and Z ranges are empty.
    % voxelId - Query the ID of a voxel based on it's x,y, and z
    %           coordinates.  This is useful if you want to see what ID that 
    %           database has assigned to an annotation after you have created it.
    % 
    % Terminology:
    %   - Dense: 3D volumetric cutout where 0 is unlabled voxels and
    %   non-zero are labled voxels (uint32)
    %   - VoxelList: Nx3 array of the x,y,z coordinates of the labeled
    %   voxels in database coordinates at the resolution you are working!
    %   (only works when operating on a single RAMON object)
    %   - MetaOnly: Query retrieves no voxel data, but only RAMON object
    %   metadata
    %
    % NOTE:
    % - Slice service does NOT return raw data, but depending on the selected
    % resolution, a scaled image for visualization purposes encoded as a png.
    % If you want a single slice of raw data use the Dense Cutout Service
    % with your z dimension span = 1
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    01-May-2012          Initial Stub
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    enumeration
        imageDense (0)
        imageSlice (1)
        annoDense (2)
        annoSlice (3)
        overlaySlice (4)
        RAMONDense (5)
        RAMONVoxelList (6)
        RAMONMetaOnly (7)
        RAMONBoundingBox (8)
        RAMONIdList (9)
        voxelId (10)
    end
    
end

