classdef eOCPConflictOption < uint32
    %eOCPConflictOption Enumeration of options for database voxel write
    %   conflict resolution.
    %
    % overwrite - overwrite existing annotations. This is the default.
    % preserve - keep existing annotations. Discard conflicting new annotations.
    % exception - keep all anotations using the exceptions capability.
    % reduce - remove voxels labeled by the uploaded annotation.
    %
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    21-Sept-2012          Initial Stub
    % D.Kleissas    09-Apr-2013           Added reduce
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    enumeration
        overwrite (0)
        preserve (1)
        exception (2)
        reduce (2)
    end
    
end

