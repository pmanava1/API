classdef eOCPPredicate < uint32
    %eOCPPredicate Enumeration of supported predicates used in ID queries
    % 0 = type - annotation type (eRAMONAnnoType)
    % 1 = status - annotation status (eRAMONAnnoStatus)
    % 2 = confidence_gt - annotation confidence is greater than a value 
    % 3 = confidence_lt - annotation confidence is les than a value 
    %
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    17-Sept-2012          Initial Stub
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    enumeration
        type (0)
        status (1)
        confidence_gt (2)
        confidence_lt (3)
    end
    
end

