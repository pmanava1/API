classdef eOCPSlicePlane < uint32
    %eOCPSlicePlane Enumeration of available slice image planes
    % 0 = xy
    % 1 = xz
    % 2 = yz
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    01-May-2012          Initial Stub
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    enumeration
        xy (0)
        xz (1)
        yz (2)
    end
    
end

