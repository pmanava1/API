classdef OCPNetwork < handle
    %OCPNetwork ************************************************
    % Provides network based methods for database interfacing
    %
    % Usage:
    %
    %  ocpNet = OCPNetwork(); Creates object
    %
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    23-AUG-2011     Initial Release
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    properties(SetAccess = 'private', GetAccess = 'public')
        %% Properties
        % Location to store server error pages.  Temp location automatically created if empty.
        errorPageLocation = [];
    end
    
    properties(SetAccess = 'private', GetAccess = 'private')
        %% Java Network Class
        % Java class provides the ability to post HDF5 files and better
        % error handling than matlab can provide natively
        jUrl = [];
        disposed = false;
    end
    
    methods( Access = public )
        %% Methods - General
        function this = OCPNetwork(varargin)
            % This class handles network communication.  You may need to
            % change the "reliableUrl" address.  It is used to verify network connectivity
            % and may not work if you are running on a LAN without
            % internet connectivity.  Change to something you know will
            % resolve as long as you are connected to the network.
            %
            %
            % this = OCPNetwork() - no semaphore (default case)
            % this = OCPNetwork(String server, int port, 
			%        String read_name, int max_permits_read, int timeout_seconds_read,
			%        String write_name, int max_permits_write, int timeout_seconds_write)
            %
            % IMPORTANT: YOU MUST HAVE A REDIS DATABASE INSTALLED AND
            % RUNNING FOR THE DISTRIBUTED SEMAPHORE TO WORK.  SERVER SHOULD
            % POINT TO THE HOST.
            %
            % ex: this = OCPNetwork("darkhelmet.jhuapl.edu",3679,"readQ",
            %                           10,0,"writeQ",20,100);
            %
            % Note:
            %   - If timeout value is 0 the class will wait forever
            %   - If read and write semaphore names are the same they will
            %     behave as a single semaphore
            
            reliableUrl = 'http://www.google.com';
            
            % Check internet connection
            try
                urlread(reliableUrl);
            catch err2
                ex = MException('OCPNetwork:NetworkError','Network connection verification failed.  Check internet connection');
                throw(ex);
            end
            
            % Setup Java network interface class
            try
                % Set up network interface class
                
                import me.openconnecto.*
                switch nargin
                    case 0
                        % No semaphore
                        this.jUrl = OcpUrl();

                    case 8
                        % Distributed Semaphore Enabled
                        this.jUrl = OcpUrl(varargin{1},varargin{2},...
                            varargin{3},varargin{4},varargin{5},varargin{6},...
                            varargin{7},varargin{8});
                       
                    otherwise
                        ex = MException('OCPNetwork:InvalidConstructor','Invalid params to the constructor.');
                        throw(ex);
                end 
                
                this.disposed = false;
            catch jErr  
                fprintf('%s\n',jErr.identifier);
                ex = MException('OCPNetwork:JavaImportError','Could not load cajal3d.jar or create OcpUrl object. \nDepending on your OS and MATLAB version, you may need to run "setupEnvironment"\nin the tools directory to add this jar file to your static path.\n\n%s',jErr.message);
                throw(ex);
            end
                
        end
        
        function delete(this)
            % destroy java object
            if this.disposed == false
                this.jUrl.dispose();
                this.jUrl = 0;
                this.disposed = true;
            end
        end
        
        function this = setErrorPageLocation(this,loc)
            % This method sets the path to save server errors pages to
            this.errorPageLocation = loc;
        end
        
        %% Methods - Semaphore
        function num = numReadPermits(this)
           num = this.jUrl.num_read_permits();    
        end        
        
        function num = numWritePermits(this)
           num = this.jUrl.num_write_permits();    
        end
        
        % Reset methods clear and reset the semaphore.  These should be
        % used with CAUTION!
        function resetReadSemaphore(this)
           this.jUrl.reset_read_semaphore();    
        end
        function resetWriteSemaphore(this)
           this.jUrl.reset_write_semaphore();    
        end
        function resetSemaphores(this)
           this.jUrl.reset_semaphores();    
        end
        
        
		% Select non-default database index if desired.  
		% Run this AFTER creating object but BEFORE a reset or lock.
        function selectDatabaseIndex(this,index)
            this.jUrl.select_database_index(index)
        end
        
        %% Query with REST args, Return PNG File
        function image = queryImage(this,urlStr)
            try
                % Get the data
                responseCode = this.jUrl.read(urlStr,false);
                if responseCode == 200
                    image = imread(char(this.jUrl.output));
                else
                    % Server errored
                    errorMessage = sprintf('Server Response %d - %s \n Error Page: <a href="%s">%s</a>\n',...
                        responseCode, char(this.jUrl.responseMessage),...
                        char(this.jUrl.output),char(this.jUrl.output));
                    
                    if ispc
                        %need to fix \
                        errorMessage = strrep(errorMessage,'\','\\');
                    end
                    
                    ex = MException('OCPNetwork:InternalServerError',errorMessage);
                    throw(ex);
                end
                
            catch err1
                try
                    urlread('http://www.jhuapl.edu');
                catch err2
                    rethrow(err2); %MATLAB:urlread:ConnectionFailed
                end
                ex = MException('OCPNetwork:BadQuery', 'Query Failed.  Internet connection OK.  Check parameters.\n\nAttempted Query: %s \n\nError Message: %s\n\n',urlStr, err1.message);
                throw(ex);
            end
        end
        
        %% test URL
        function testUrl(this,urlStr)
            try
                % Get the data
                responseCode = this.jUrl.read(urlStr,false);
                if responseCode ~= 200
                    % Server errored
                    errorMessage = sprintf('Server Response %d - %s \n Error Page: <a href="%s">%s</a>\n',...
                        responseCode, char(this.jUrl.responseMessage),...
                        char(this.jUrl.output),char(this.jUrl.output));
                    
                    if ispc
                        %need to fix \
                        errorMessage = strrep(errorMessage,'\','\\');
                    end
                    
                    ex = MException('OCPNetwork:InternalServerError',errorMessage);
                    throw(ex);
                end
                
            catch err1                
                try
                    urlread('http://www.jhuapl.edu');
                catch err2
                    rethrow(err2); %MATLAB:urlread:ConnectionFailed
                end
                ex = MException('OCPNetwork:BadQuery', 'Query Failed.  Internet connection OK.  Check parameters.\n\nAttempted Query: %s \n\nError Message: %s\n\n',urlStr, err1.message);
                throw(ex);
            end
        end
        
        %% Read/Write Queries 
        function output = read(this,urlStr,hdfFile)
        % This method queries a RESTful web service to read data
        % It also supports posting an HDF5 file with the request.
            
            if ~exist('hdfFile','var')                
                output = this.processQueryResponse(this.jUrl.read(urlStr,false));
            else              
                output = this.processQueryResponse(this.jUrl.read(urlStr,hdfFile,false));
            end
        end
        
        function output = write(this,urlStr,hdfFile)
        % This method queries a RESTful web service to write data
        % It supports posting an HDF5 file with the request.
            if ~exist('hdfFile','var')                
                output = this.processQueryResponse(this.jUrl.write(urlStr,false));
            else              
                output = this.processQueryResponse(this.jUrl.write(urlStr,hdfFile,false));
            end
        end
        
        function output = readCached(this,urlStr,hdfFile)
        % This method queries a RESTful web service to read data
        % It also supports posting an HDF5 file with the request.
        %
        % This method has ALL CACHING ENABLED.  Use this for getting
        % stable data only (i.e. image databases).  There is a
        % possiblity that if serverside data changes you will NOT see
        % it.
        
            if ~exist('hdfFile','var')                
                output = this.processQueryResponse(this.jUrl.read(urlStr,true));
            else              
                output = this.processQueryResponse(this.jUrl.read(urlStr,hdfFile,true));
            end
        end
        
        
        %% Process query response
        function output = processQueryResponse(this, responseCode)
            if responseCode ~= 200
                % Some error Occured - Write out debug info
                if isempty(this.errorPageLocation)
                    errorPagePath = char(this.jUrl.output);
                else
                    errorPagePath = fullfile(this.errorPageLocation,[datestr(now,30) '.html']);
                    copyfile(char(this.jUrl.output),errorPagePath);
                end
                
                errorMessage = sprintf('Server Response %d - %s \n Error Page: <a href="%s">%s</a>\n',...
                    responseCode, char(this.jUrl.responseMessage),...
                    errorPagePath,errorPagePath);
                
                if ispc
                    %need to fix \
                    errorMessage = strrep(errorMessage,'\','\\');
                end
                
                ex = MException('OCPNetwork:InternalServerError',errorMessage);
                throw(ex);
                
            else
                % Looks Good
                output = char(this.jUrl.output);
            end
        end
        
        %% Send HTTP DELETE request on a URL
        function output = deleteRequest(this,urlStr)
            % This method sends a url using a delete request
            
            % Do delete
            responseCode = this.jUrl.delete(urlStr);
            
            
            if responseCode ~= 200
                % Some error Occured - Write out debug info
                if isempty(this.errorPageLocation)
                    errorPagePath = char(this.jUrl.output);
                else
                    errorPagePath = fullfile(this.errorPageLocation,[datestr(now,30) '.html']);
                    copyfile(char(this.jUrl.output),errorPagePath);
                end
                
                errorMessage = sprintf('Server Response %d - %s \n Error Page: <a href="%s">%s</a>\n',...
                    responseCode, char(this.jUrl.responseMessage),...
                    errorPagePath,errorPagePath);
                
                if ispc
                    %need to fix \
                    errorMessage = strrep(errorMessage,'\','\\');
                end
                
                ex = MException('OCPNetwork:InternalServerError',errorMessage);
                throw(ex);
                
            else
                % Looks Good
                output = char(this.jUrl.output);
            end            
        end
    end
end
