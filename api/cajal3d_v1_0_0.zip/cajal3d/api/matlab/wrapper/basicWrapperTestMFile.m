%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% � 2012 The Johns Hopkins University / Applied Physics Laboratory.  All Rights Reserved.
% Proprietary Until Publicly Released
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function basicWrapperTestMFile(double,str,mat,bool)
    %matlabInitTestFunction Function used by the matlabInit unit test
    fprintf('Double Value=%f\n',double);    
    fprintf('String=%s\n',str); 
    fprintf('Matrix Elements=%d %d %d %d\n',mat(1,1),mat(1,2),mat(2,1),mat(2,2));  
    fprintf('Boolean=%d\n',bool);  
end

