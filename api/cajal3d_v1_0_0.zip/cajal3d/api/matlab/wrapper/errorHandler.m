function errorHandler(ME)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% � 2012 The Johns Hopkins University / Applied Physics Laboratory.  All Rights Reserved.
% Proprietary Until Publicly Released
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Capture and print erro so it gets sent to the standard out stream
errorTime = datestr(now);

errStr = sprintf('\n@@@ MATLAB ERROR - %s @@@\n\n', errorTime);
errStr = sprintf('%sIdentifier: %s\n',errStr,ME.identifier);
errStr = sprintf('%sMessage: %s\n',errStr,ME.message);
errStr = sprintf('%sCause:\n',errStr);
for ii = 1:length(ME.cause)
    errStr = sprintf('%s %s\n',errStr,ME.cause{ii});
end

s = ME.stack;
errStr = sprintf('%sStack:\n',errStr);
for ii = 1:length(s)
    fstr = strrep(s(ii).file,'\','\\');
    errStr = sprintf('%s\n File: %s \n',errStr,fstr);
    errStr = sprintf('%s Method: %s \n',errStr,s(ii).name);
    errStr = sprintf('%s Line: %d \n',errStr,s(ii).line);
end

errStr = sprintf('%s\n@@@ MATLAB ERROR - %s @@@\n\n',errStr,errorTime);

fprintf(errStr);


end