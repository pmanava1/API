classdef RAMONGeneric <  RAMONVolume
    %RAMONGeneric ************************************************
    % Generic Annotation Class used to capture basic annotations before they
    % have been attributed to a RAMON type, or to accomodate data that does
    % not have a RAMON type.  You should try to fit into the RAMON
    % data model and use this object as an intermediate product
    %
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    23-AUG-2011     Initial Release
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    properties(SetAccess = 'private', GetAccess = 'public')
        
    end
    
    methods
        function this = RAMONGeneric()
            % Constructor
            
        end
        
        function handle = clone(this, option)
            % Perform a deep copy because these are handles and not
            % objects.
            % Default using the = operator just copies the handle and not
            % the underlying object.
            %
            % Optionally pass in 'novoxels' to perform copy without voxel
            % data
            %
            % ex: new_obj = my_obj.clone('novoxels');
            
            if ~exist('option','var');
                option = [];
            end
            
            % Instantiate new object of the same class.
            handle = feval(class(this));
            
            % Copy all properties.
            % Base
            handle = this.baseCloneHelper(handle);
            % Volume
            handle = this.volumeCloneHelper(handle,option);
        end
        
        
        
        %% RAMON Converstion Methods
        function ramonObj = toSynapse(this)
            ramonObj = RAMONSynapse();
            ramonObj = this.setRAMONBaseProperties(ramonObj);
            ramonObj = this.setRAMONVolumeProperties(ramonObj);
        end
        
        function ramonObj = toSeed(this)
            ramonObj = RAMONSeed();
            ramonObj = this.setRAMONBaseProperties(ramonObj);
        end
        
        function ramonObj = toSegment(this)
            ramonObj = RAMONSegment();
            ramonObj = this.setRAMONBaseProperties(ramonObj);
            ramonObj = this.setRAMONVolumeProperties(ramonObj);
        end
        
        function ramonObj = toNeuron(this)
            ramonObj = RAMONNeuron();
            ramonObj = this.setRAMONBaseProperties(ramonObj);
        end
        
        
    end
end

