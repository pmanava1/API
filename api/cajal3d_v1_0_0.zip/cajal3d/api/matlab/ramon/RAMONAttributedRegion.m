classdef RAMONAttributedRegion < RAMONVolume
    %RAMONAttributedRegion ************************************************
    % Currently not implemented server side.
    %
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    25-SEPT-2011     Initial Release
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % � 2012 The Johns Hopkins University / Applied Physics Laboratory.  All Rights Reserved.
    % Proprietary Until Publicly Released
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    properties(SetAccess = 'private', GetAccess = 'public')
        
    end
    
    methods
        function this = RAMONAttributedRegion()
            % Constructor
            
            ex = MException('RAMONAttributedRegion:Unsupported','RAMONAttributedRegion type not yet supported.');
            throw(ex);
        end
        
        
        
    end
end

