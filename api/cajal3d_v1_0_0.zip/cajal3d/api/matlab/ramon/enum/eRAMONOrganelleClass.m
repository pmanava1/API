classdef eRAMONOrganelleClass < int32
    %RAMONOrgannelClass Enumeration of organelle classifications
    % 0 = Unknown
    % 1 = Mitochondria
    % 2 = Vesicle
    % 3 = Axoplasmic Reticula
    % 4 = Microtubules
    % 5 = Nucleus
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    23-AUG-2011     Initial Release
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    enumeration
        unknown (0)
        mitochondria (1)
        vesicle (2)
        axoplasmicReticula (3)
        microtubules (4)
        nucleus (5)
    end
    
end

