classdef eRAMONSynapseType < int32
    %RAMONFlowDirection Enumeration of information flow direction for
    %synapse and segments
    % 0 = Unknown
    % 1 = Excitatory synapse
    % 2 = Inhibitory synapse
    % 3 = Gap Junction
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    23-AUG-2011     Initial Release
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    enumeration
        unknown (0)
        excitatory (1)
        inhibitory (2)
        gapJunction (3)
    end
    
end

