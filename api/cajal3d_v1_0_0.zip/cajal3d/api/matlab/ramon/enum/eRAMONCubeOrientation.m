classdef eRAMONCubeOrientation < int32
    %RAMONCubeOrientation Enumeration of possible cube orientations
    % This is used in the RAMONSeed class.  It indicatates how a cube
    % should be generated around a seed.
    %     pos_x - place the seed in the center of the +x face
    %     neg_x - place the seed in the center of the -x face 
    %     pos_y - place the seed in the center of the +y face 
    %     neg_y - place the seed in the center of the -y face 
    %     pos_z - place the seed in the center of the +z face 
    %     neg_z - place the seed in the center of the -z face 
    %     centered - center the cube around the seed
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    23-AUG-2011     Initial Release
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    enumeration
        pos_x (0)
        neg_x (1)
        pos_y (2)
        neg_y (3)
        pos_z (4)
        neg_z (5)
        centered (6)
    end
    
end

