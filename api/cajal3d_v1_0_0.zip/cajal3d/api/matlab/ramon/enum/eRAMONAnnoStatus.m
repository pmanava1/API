classdef eRAMONAnnoStatus < int32
    %eRAMONAnnoStatus Enumeration of status field values for RAMON annotations
    % 0 = Unprocessed
    % 1 = Locked
    % 2 = Processing
    % 3 = Ignored
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    23-AUG-2011     Initial Release
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    
    enumeration
        unprocessed (0)
        locked (1)
        processed (2)
        ignored (3)
    end
    
end

