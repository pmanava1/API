classdef eRAMONSegmentClass < int32
    %RAMONSegmentClass Enumeration of segment classes
    % 0 = Unknown
    % 1 = Axon (fragment)
    % 2 = Dendrite (fragment)
    % 3 = Soma (fragment) 
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    23-AUG-2011     Initial Release
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    enumeration
        unknown (0)
        axon (1)
        dendrite (2)
        soma (3)
    end
    
end

