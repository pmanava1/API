classdef eRAMONAnnoType < int32
    %eRAMONAnnoType Enumeration of the types of RAMON annotations
    %that can be stored in the OCP annotation database
    %
    
    % Generic = 1
    % SYNAPSE = 2
    % SEED = 3
    % SEGMENT = 4
    % NEURON = 5
    % ORGANELLE = 6
    % ATTRIBUTEDREGION = 7
    % VOLUME = 8
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    23-AUG-2011     Initial Release
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    enumeration
        generic(1)
        synapse (2)
        seed (3)
        segment (4)
        neuron (5)
        organelle (6) % not supported yet
        attributedRegion (7) % not support yet
        volume(8)
    end
    
end

