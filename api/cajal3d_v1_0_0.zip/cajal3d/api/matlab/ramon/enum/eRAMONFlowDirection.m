classdef eRAMONFlowDirection < int32
    %RAMONFlowDirection Enumeration of information flow direction for
    %synapse and segments
    % 0 = Unknown
    % 1 = Pre-Synaptic
    % 2 = Post-Synaptic
    % 3 = Bi-Directional
    %
    %                       Revision History
    % Author            Date                Comment
    % D.Kleissas    23-AUG-2011     Initial Release
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    enumeration
        unknown (0)
        preSynaptic (1)
        postSynaptic (2)
        biDirectional (3)
    end
    
end

