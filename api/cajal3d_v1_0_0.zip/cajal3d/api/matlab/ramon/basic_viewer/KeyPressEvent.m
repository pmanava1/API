%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% � 2012 The Johns Hopkins University / Applied Physics Laboratory.  All Rights Reserved.
% Proprietary Until Publicly Released
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

classdef KeyPressEvent < event.EventData
    properties
        Character = 0;
    end
    methods
        function eventData = KeyPressEvent(value)
           eventData.Character = value; 
        end
    end
end
