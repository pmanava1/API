%setupEnvironment ************************************************
% Script to set up classpath.txt and startup.m for your matlab installation
% to support the CAJAL3D framwork.
%
%
%
% Author: Dean Kleissas
%        dean.kleissas@jhuapl.edu
%                           Revision History
% Author            Date             Comment
% D.Kleissas    13-MAR-2012      Initial creation
% D.Kleissas    22-MAY-2012      Fixed to handle linux vs mac/windows
% D.Kleissas    30-SEPT-2012     Updates to make more robust.  Fixes for
%                                cross platform
% D.Kleissas    04-DEC-2012      Added hazelcast.jar
% D.Kleissas    08-JAN-2013      Removed hazelcast.jar. Added jedis-2.1.0.jar
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (c) 2012 The Johns Hopkins University / Applied Physics Laboratory.  All Rights Reserved.
% Proprietary Until Publicly Released
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
%% Verify dir

% Make sure you are running from /tools/matlab_install/
if isempty(strfind(pwd,fullfile('tools','matlab_install')))
    error('Please run setup script from /tools/matlab_install/ relative to the framework directory.');
end

%% Choose install type
loopflag = 1;
questStr = sprintf('\nWould you like to change your startup.m file so that CAJAL3D API \ngets added to the MATLAB search path at startup?  (Y or N): ');
strResponse = input(questStr, 's');

while loopflag == 1
    switch strResponse
        case {'Y','y'}
            loopflag = 0;
            autoStartup = 1;
        case {'N','n'}
            autoStartup = 0;
            loopflag = 0;
        otherwise
            strResponse = input('Please enter either "Y" for yes or "N" for no:', 's');
    end
end


%% Overwrite warning
if autoStartup == 1
    loopflag = 1;
    questStr = sprintf('\n*** Warning: This will update your existing startup.m file.  Do you wish to continue?? (Y or N):');
    strResponse = input(questStr, 's');
    
    while loopflag == 1
        switch strResponse
            case {'Y','y'}
                loopflag = 0;
                autoStartup = 1;
            case {'N','n'}
                autoStartup = 0;
                loopflag = 0;
            otherwise
                strResponse = input('Please enter either "Y" for yes or "N" for no:', 's');
        end
    end
end
%% Common Setup

% Get path info
frameworkRoot = pwd;
ind = strfind(frameworkRoot,filesep);
frameworkRoot(ind(end-1):end) = [];

%% Check OS/OS specific setup
str = computer('arch');
switch str
    case {'maci64'}
        %% Setup OSX/Windows
        if isempty(which('startup'))
            p = userpath;
            startupFilePath = strtok(p,':');
        else
            startupFilePath = which('startup');
            [startupFilePath, ~, ~] = fileparts(startupFilePath);
        end
        
        startupString = sprintf('run(''%s/cajal3d'');\n',frameworkRoot);
        
    case {'win64','win32'}
        %% Setup OSX/Windows
        if isempty(which('startup'))
            p = userpath;
            startupFilePath = strtok(p,';');
        else
            startupFilePath = which('startup');
            [startupFilePath, ~, ~] = fileparts(startupFilePath);
        end
        
        startupString = sprintf('run(''%s\\cajal3d'');\n',frameworkRoot);
    case {'glnx86','glnxa64'}
        %% Setup linux
        if isempty(which('startup'))
            p = userpath;
            startupFilePath = p(1:end-1);
        else
            startupFilePath = which('startup');
            [startupFilePath, ~, ~] = fileparts(startupFilePath);
        end
        
        startupString = sprintf('run(''%s/cajal3d'');\n',frameworkRoot);
    otherwise
        error('Unsupported OS: %s\n',str);
end

%% Write Startup File if you can
if autoStartup == 1
    
    fprintf('\nAttempting to update Matlab Startup File - Method 1: ');
    try
                
        if exist(fullfile(startupFilePath,'startup.m'), 'file') == 2
            % If a startup.m file already exists read it in 
            
            % Open file
            fid = fopen(fullfile(startupFilePath,'startup.m'),'r');
            
            if fid == -1
                error('could not open startup.m to read');
            end
            
            
            % Read all of the file in.
            clear startupData
            tline = fgets(fid);
            startupData{1} = tline;
            cnt = 2;
            while ischar(tline)
                tline = fgets(fid);
                startupData{cnt} = tline;  %#ok<SAGROW>
                cnt = cnt + 1;
            end
            if startupData{end} == -1
                startupData(end) = [];
            end
            
            % If cajal3d already in there, update.
            ind = strfind(startupData,'cajal3d');
            ind = ~cellfun(@isempty,ind);
            ind = find(ind == 1);
            
            if length(ind) > 1
                % More than one instance of cajal3d found so don't know
                % what to do.
                error('Don''t know where to write.');
                
            elseif isempty(ind)
                % Nothing there so append.
                startupData{end + 1} = startupString;
                
            else
                % One line found.  Update it.
                startupData{ind} = startupString;
            end
            
            % Close file so you can back it up and then write it
            fclose(fid);
            
            % Back up file
            copyfile(fullfile(startupFilePath,'startup.m'),fullfile(startupFilePath,['startup_backup_' datestr(now,30)]));
            
        else
            % The file doesn't exist yet so just write it.
            startupData{1} = startupString;
        end
        
        % Write out file
        fid = fopen(fullfile(startupFilePath,'startup.m'),'w+');
        
        if fid == -1
            error('could not open startup.m to write');
        end
        
        for ii = 1:length(startupData)
            fprintf(fid,'%s',startupData{ii});
        end
        fclose(fid);
        
        
        fprintf('Success\n');
        
    catch ME
        % if you don't have write permissions, you must do it as admin
        fprintf('Failed');
        
        fprintf('\n\n%s\n\nStartup File: %s\nAdd Line: %s\n\n%s\n\n','If you''d like to auto-configure on startup add the following line to your startup.m:',...
            fullfile(startupFilePath,'startup.m'),startupString,'Otherwise call ''cajal3d'' (located in the framework root) before using API classes');
    end
else
    fprintf('\n\n%s\n\nStartup File: %s\nAdd Line: %s\n\n%s\n\n','If you''d like to auto-configure on startup add the following line to your startup.m:',...
        fullfile(startupFilePath,'startup.m'),startupString,'Otherwise call ''cajal3d'' (located in the framework root) before using API classes');
end


%% Set up Java Class Path Work-around
% dynamic javapath doesn't work reliably so update static file

jarFile1 = fullfile(frameworkRoot,'resources','hsqldb','lib','hsqldb.jar');
jarFile2 = fullfile(frameworkRoot,'api','matlab','ocp','cajal3d.jar');
jarFile3 = fullfile(frameworkRoot,'api','matlab','ocp','jedis-2.1.0.jar');

fprintf('Attempting to update Matlab Static Java Class Path - Method 1: ');

try
    % Open file
    classPathFile = which('classpath.txt');
    fid = fopen(classPathFile,'r');
    if fid == -1
        error('could not open classpath.txt to read');
    end
    
    % Read all of the file in.
    clear classpathData
    tline = fgets(fid);
    classpathData{1} = tline;
    cnt = 2;
    while ischar(tline)
        tline = fgets(fid);
        classpathData{cnt} = tline;  %#ok<SAGROW>
        cnt = cnt + 1;
    end
    if classpathData{end} == -1
        classpathData(end) = [];
    end
    
    % If cajal3d already in there, update.
    ind1 = strfind(classpathData,'hsqldb.jar');
    ind1 = ~cellfun(@isempty,ind1);
    ind1 = find(ind1 == 1);
    ind2 = strfind(classpathData,'cajal3d.jar');
    ind2 = ~cellfun(@isempty,ind2);
    ind2 = find(ind2 == 1);
    ind3 = strfind(classpathData,'jedis-2.1.0.jar');
    ind3 = ~cellfun(@isempty,ind3);
    ind3 = find(ind3 == 1);
    
    if length(ind1) > 1
        % More than one instance of cajal3d found so don't know
        % what to do.
        error('Don''t know where to write.');
        
    elseif isempty(ind1)
        % Nothing there so append.
        classpathData{end + 1} = sprintf('%s\n',jarFile1);
        
    else
        % One line found.  Update it.
        classpathData{ind1} = sprintf('%s\n',jarFile1);
    end
    
    if length(ind2) > 1
        % More than one instance of cajal3d found so don't know
        % what to do.
        error('Don''t know where to write.');
        
    elseif isempty(ind2)
        % Nothing there so append.
        classpathData{end + 1} = sprintf('%s\n',jarFile2);
        
    else
        % One line found.  Update it.
        classpathData{ind2} = sprintf('%s\n',jarFile2);
    end
    
    if length(ind3) > 1
        % More than one instance of hazelcast.jar found so don't know
        % what to do.
        error('Don''t know where to write hazelcast.');
        
    elseif isempty(ind3)
        % Nothing there so append.
        classpathData{end + 1} = sprintf('%s\n',jarFile3);
        
    else
        % One line found.  Update it.
        classpathData{ind3} = sprintf('%s\n',jarFile3);
    end
    
    % Close file so you can back it up and then write it
    fclose(fid);
    
    % Write out file
    fid = fopen(classPathFile,'w+');    
    if fid == -1
        error('could not open classpath.txt to write');
    end
    
    % Back up file
    [pathstr, name, ext] = fileparts(classPathFile);
    copyfile(classPathFile,fullfile(pwd,[name '_backup_' datestr(now,30) ext]));
    
    for ii = 1:length(classpathData)
        fprintf(fid,'%s',classpathData{ii});
    end
    fclose(fid);
    
    
    fprintf('Success\n');
    sudoClasspath = 0;
    
catch ME
    % if you don't have write permissions, you must do it as admin
    fprintf('Failed\n');
    sudoClasspath = 1;
end



%% Write external script if needed (root priv required to finish setup)
if sudoClasspath == 1
    
    fprintf('Attempting to update Matlab Static Java Class Path - Method 2: \n');
    try
        % Based on OS write script and run as admin
        str = computer('arch');
        switch str
            case {'win64','win32'}
                %% Setup Windows               
                fid = fopen(fullfile(pwd,'run_this_script_elevated.bat'),'wt+');
                
                % Write header to get windows UAC to pop up...
                fprintf(fid,'@echo off\n');
                fprintf(fid,'mkdir "%%windir%%\\BatchGotAdmin"\n');
                fprintf(fid,'if ''%%errorlevel%%'' == ''0'' (\n');
                fprintf(fid,'  rmdir "%%windir%%\\BatchGotAdmin" & goto gotAdmin \n');
                fprintf(fid,') else ( goto UACPrompt )\n');
                fprintf(fid,':UACPrompt\n');
                fprintf(fid,'    echo Set UAC = CreateObject^("Shell.Application"^) > "%%temp%%\\getadmin.vbs"\n');
                fprintf(fid,'    echo UAC.ShellExecute %%0, "", "", "runas", 1 >> "%%temp%%\\getadmin.vbs"\n');
                fprintf(fid,'    "%%temp%%\\getadmin.vbs"\n');
                fprintf(fid,'    exit /B\n');
                fprintf(fid,':gotAdmin\n');
                fprintf(fid,'    if exist "%%temp%%\\getadmin.vbs" ( del "%%temp%%\\getadmin.vbs" )\n');
                fprintf(fid,'    pushd "%%CD%%"\n');
                fprintf(fid,'    CD /D "%%~dp0"\n');
                fprintf(fid,'\n\n');

                % Backup file
                fprintf(fid,'echo Backup Existing Classpath.txt\n');
                [pathstr, name, ext] = fileparts(classPathFile);
                fprintf(fid,'copy "%s" "%s"\n\n',...
                    classPathFile,...
                    fullfile(pathstr,['classpath_backup_' datestr(now,30) '.txt']));
                
                % Remove line if it already exists
                fprintf(fid,'echo Remove references if exist\n');
                newName = fullfile(pathstr, [name '_tmp' ext]);
                cmd = sprintf('type "%s" | findstr /v jedis-2.1.0.jar | findstr /v hsqldb.jar | findstr /v cajal3d.jar > "%s"',...
                    classPathFile,...
                    newName);
                fprintf(fid,'%s\n',cmd);
                cmd = sprintf('move /y "%s" "%s"',newName,classPathFile);
                fprintf(fid,'%s\n\n',cmd);
                                                                          
                % append to class path
                fprintf(fid,'echo Append to classpath.txt\n');
                fprintf(fid,'echo %s >> "%s"\n',jarFile1,classPathFile);
                fprintf(fid,'echo %s >> "%s"\n',jarFile2,classPathFile);
                fprintf(fid,'echo %s >> "%s"\n',jarFile3,classPathFile);
                fprintf(fid,'pause\n');
                
                fclose(fid);
                
                % Call script
                fprintf('\n<><><><><><><><> IMPORTANT <><><><><><><><>\n');
                fprintf('If you have issues creating OCP objects with errors saying the function ''OcpUrl'' is not found,\n');
                fprintf('your version of MATLAB is most likely having issues with the dynamic java class path.\n');
                fprintf('To work around this, please double click on script located in this directory called "run_this_script_elevated.bat"\n');
                fprintf('You must do this OUTSIDE MATLAB in windows explorer. UAC will ask for permission.\n');
                fprintf('<><><><><><><><> IMPORTANT <><><><><><><><>\n\n');
                
            case {'maci64','glnx86','glnxa64'}
                %% Setup linux, OSX               
                fid = fopen(fullfile(pwd,'run_this_script_as_root.sh'),'wt+');
                
                % Backup file
                fprintf(fid,'#Backup Existing Classpath.txt\n');
                [pathstr, name, ext] = fileparts(classPathFile);
                fprintf(fid,'cp %s %s\n\n',...
                    classPathFile,...
                    fullfile(pathstr,['classpath_backup_' datestr(now,30) '.txt']));
                
                % Remove line if it already exists
                fprintf(fid,'#Remove references if exist\n');
                newName = fullfile(pathstr, [name '_tmp' ext]);
                cmd = sprintf('sed ''/hsqldb.jar/d'' %s > %s',...
                    classPathFile,...
                    newName);
                fprintf(fid,'%s\n',cmd);
                cmd = sprintf('mv %s %s',newName,classPathFile);
                fprintf(fid,'%s\n\n',cmd);
                
                newName = fullfile(pathstr, [name '_tmp' ext]);
                cmd = sprintf('sed ''/cajal3d.jar/d'' %s > %s',...
                    classPathFile,...
                    newName);
                fprintf(fid,'%s\n',cmd);
                cmd = sprintf('mv %s %s',newName,classPathFile);
                fprintf(fid,'%s\n\n',cmd);
                
                newName = fullfile(pathstr, [name '_tmp' ext]);
                cmd = sprintf('sed ''/jedis-2.1.0.jar/d'' %s > %s',...
                    classPathFile,...
                    newName);
                fprintf(fid,'%s\n',cmd);
                cmd = sprintf('mv %s %s',newName,classPathFile);
                fprintf(fid,'%s\n\n',cmd);
                                
                % append to class path
                fprintf(fid,'#Append to classpath.txt\n');
                fprintf(fid,'echo "%s" >> "%s"\n',jarFile1,classPathFile);
                fprintf(fid,'echo "%s" >> "%s"\n',jarFile2,classPathFile);
                fprintf(fid,'echo "%s" >> "%s"\n',jarFile3,classPathFile);
                
                fclose(fid);
                
                % Call script
                fprintf('Now running generated script as ROOT (you must be able to sudo) to finish configuration: ');
                !sudo sh ./run_this_script_as_root.sh
                
            otherwise
                error('Unsupported OS: %s\n',str);
        end
        
        
        fprintf('Success.\n\n');
        
    catch ME
        fprintf('failed.\n');
        fprintf('\n\n%s\n\nClass Path File: %s\nAdd Line: %s\nAdd Line: %s\nAdd Line: %s\n','Failed to automatically update the static class path.  Please manually update!',...
            classPathFile,jarFile1,jarFile2,jarFile3);
    end
    
end

%% Close MATLAB
fprintf('Setup Complete!\n\n *** You must restart MATLAB for changes to take effect ***\n\n');



