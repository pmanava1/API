classdef SemaphoreTool
    %SEMTOOL Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        jedisCli = [];
        settings = [];
        disposed = false;
    end
    
    methods
        function this = SemaphoreTool()
            % Setup Java network interface class
            try
                % Set up redis client
                
                import redis.clients.*
                
                load(fullfile(fileparts(which('cajal3d')),'api','matlab','ocp','ocp_settings.mat'));
                this.settings = ocp_settings;
                this.jedisCli = jedis.Jedis(ocp_settings.server,ocp_settings.port);
                
                
                this.disposed = false;
            catch jErr
                fprintf('%s\n',jErr.identifier);
                ex = MException('OCPNetwork:JavaImportError','Could not load cajal3d.jar or create OcpUrl object. \nDepending on your OS and MATLAB version, you may need to run "setupEnvironment"\nin the tools directory to add this jar file to your static path.\n\n%s',jErr.message);
                throw(ex);
                
            end
        end
        
        function this = delete(this)
            % destroy java object
            if this.disposed == false
                this.jedisCli.quit();
                this.jedisCli = 0;
                this.disposed = true;
            end
        end
        
        function info(this)
            infostr = this.jedisCli.info();
            fprintf('\n######### REDIS INFO:\n\n%s\n\n',char(infostr));
        end
        
        function flushAll(this)
            response = this.jedisCli.flushAll();
            fprintf('\n Flush ALL Keys:%s\n\n',char(response));
        end
        
        function selectDatabaseIndex(this,index)
            this.jedisCli.select(index);
        end
        
        
        function status(this)
            load(fullfile(fileparts(which('cajal3d')),'api','matlab','ocp','ocp_settings.mat'));
            this.settings = ocp_settings;
            
            % Check if semaphores exist
            rExist = this.jedisCli.exists([this.settings.read_semaphore ':EXISTS']);
            wExist = this.jedisCli.exists([this.settings.write_semaphore ':EXISTS']);
            
            % Check available permits
            if rExist.booleanValue
                rPermits = this.jedisCli.llen([this.settings.read_semaphore ':LIST']);
                rStr = sprintf('%d of %d Permits Available',double(rPermits),this.settings.max_read_permits);
            else
                rStr = 'Not Configured';
            end
            
            if wExist.booleanValue
                wPermits = this.jedisCli.llen([this.settings.write_semaphore ':LIST']);
                wStr = sprintf('%d of %d Permits Available',double(wPermits),this.settings.max_write_permits);
            else
                wStr = 'Not Configured';
            end
            
            % Print Status
            fprintf('Read  Semaphore Status: %s\n',rStr);
            fprintf('Write Semaphore Status: %s\n\n',wStr);
            
        end
        
        function monitor(this)
            load(fullfile(fileparts(which('cajal3d')),'api','matlab','ocp','ocp_settings.mat'));
            this.settings = ocp_settings;
            
            while(1)
                
                % Check if semaphores exist
                rExist = this.jedisCli.exists([this.settings.read_semaphore ':EXISTS']);
                wExist = this.jedisCli.exists([this.settings.write_semaphore ':EXISTS']);
                
                % Check available permits
                if rExist.booleanValue
                    rPermits = this.jedisCli.llen([this.settings.read_semaphore ':LIST']);
                    rStr = sprintf('%d of %d Permits Available',double(rPermits),this.settings.max_read_permits);
                else
                    rStr = 'Not Configured';
                end
                
                if wExist.booleanValue
                    wPermits = this.jedisCli.llen([this.settings.write_semaphore ':LIST']);
                    wStr = sprintf('%d of %d Permits Available',double(wPermits),this.settings.max_write_permits);
                else
                    wStr = 'Not Configured';
                end
                
                % Print Status
                clc
                fprintf('Read  Semaphore Status: %s\n',rStr);
                fprintf('Write Semaphore Status: %s\n\n',wStr);
                fprintf('Press CNTL+C to stop...');
                
                pause(1)
                
            end
            
            
        end
        
        function resetRead(this)
            import me.openconnecto.*
            jUrl = OcpUrl(this.settings.server,this.settings.port,...
                this.settings.read_semaphore,this.settings.max_read_permits,this.settings.read_timeout_seconds,...
                this.settings.write_semaphore,this.settings.max_write_permits,this.settings.write_timeout_seconds);
            jUrl.reset_read_semaphore();
            
        end
        
        function resetWrite(this)
            import me.openconnecto.*
            jUrl = OcpUrl(this.settings.server,this.settings.port,...
                this.settings.read_semaphore,this.settings.max_read_permits,this.settings.read_timeout_seconds,...
                this.settings.write_semaphore,this.settings.max_write_permits,this.settings.write_timeout_seconds);
            jUrl.reset_write_semaphore();
        end
        
        function resetAll(this)
            import me.openconnecto.*
            jUrl = OcpUrl(this.settings.server,this.settings.port,...
                this.settings.read_semaphore,this.settings.max_read_permits,this.settings.read_timeout_seconds,...
                this.settings.write_semaphore,this.settings.max_write_permits,this.settings.write_timeout_seconds);
            jUrl.reset_semaphores();
        end
        
        
        function configure(this)
            
            % Check if you want to do it
            loopflag = 1;
            questStr = sprintf('\nDo you want to change the distributed semaphore configuration?\nWARNING: THIS WILL RESET THE SERVER SEMAPHORE AND CAN CAUSE PROBLEMS IF PROCESSING IS CURRENTLY RUNNING  (Y or N): ');
            strResponse = input(questStr, 's');
            
            while loopflag == 1
                switch strResponse
                    case {'Y','y'}
                        loopflag = 0;
                    case {'N','n'}
                        fprintf('Configuration cancelled...\n');
                        return
                    otherwise
                        strResponse = input('Please enter either "Y" for yes or "N" for no:', 's');
                end
            end
            
            % Get new values
            fprintf('Enter new values, press return to accept current value in parentheses...\n\n')
            questStr = sprintf('Server (%s): ',this.settings.server);
            response = input(questStr, 's');
            if isempty(response)
                newSettings.server = this.settings.server;
            else
                newSettings.server = response;
            end
            
            questStr = sprintf('Port (%d): ',this.settings.port);
            response = input(questStr, 's');
            if isempty(response)
                newSettings.port = this.settings.port;
            else
                newSettings.port = str2double(response);
            end
            
            questStr = sprintf('Read Semaphore Name (%s): ',this.settings.read_semaphore);
            response = input(questStr, 's');
            if isempty(response)
                newSettings.read_semaphore = this.settings.read_semaphore;
            else
                newSettings.read_semaphore = response;
            end
            
            questStr = sprintf('Max Read Permits (%d): ',this.settings.max_read_permits);
            response = input(questStr, 's');
            if isempty(response)
                newSettings.max_read_permits = this.settings.max_read_permits;
            else
                newSettings.max_read_permits = str2double(response);
            end
            
            questStr = sprintf('Read Timeout in Seconds (%d): ',this.settings.read_timeout_seconds);
            response = input(questStr, 's');
            if isempty(response)
                newSettings.read_timeout_seconds = this.settings.read_timeout_seconds;
            else
                newSettings.read_timeout_seconds = str2double(response);
            end
            
            questStr = sprintf('Write Semaphore Name (%s): ',this.settings.write_semaphore);
            response = input(questStr, 's');
            if isempty(response)
                newSettings.write_semaphore = this.settings.write_semaphore;
            else
                newSettings.write_semaphore = response;
            end
            
            questStr = sprintf('Max Write Permits (%d): ',this.settings.max_write_permits);
            response = input(questStr, 's');
            if isempty(response)
                newSettings.max_write_permits = this.settings.max_write_permits;
            else
                newSettings.max_write_permits = str2double(response);
            end
            
            questStr = sprintf('Write Timeout in Seconds (%d): ',this.settings.write_timeout_seconds);
            response = input(questStr, 's');
            if isempty(response)
                newSettings.write_timeout_seconds = this.settings.write_timeout_seconds;
            else
                newSettings.write_timeout_seconds = str2double(response);
            end
            
            
            % Display result and check if you want to commit changes
            fprintf('\n\nNew Settings:\n\n');
            disp(newSettings);
            
            loopflag = 1;
            questStr = sprintf('\nDo you want to commit these changes to the local file system and Redis Server? (Y or N): ');
            strResponse = input(questStr, 's');
            
            while loopflag == 1
                switch strResponse
                    case {'Y','y'}
                        loopflag = 0;
                    case {'N','n'}
                        fprintf('Configuration cancelled...\n');
                        return
                    otherwise
                        strResponse = input('Please enter either "Y" for yes or "N" for no:', 's');
                end
            end
                        
            % Update class
            this.settings = newSettings;
            
            % Update File
            ocp_settings = newSettings; %#ok<NASGU>
            save(fullfile(fileparts(which('cajal3d')),'api','matlab','ocp','ocp_settings.mat'),'ocp_settings');
            
            % Update Redis DB
            import me.openconnecto.*
            jUrl = OcpUrl(this.settings.server,this.settings.port,...
                this.settings.read_semaphore,this.settings.max_read_permits,this.settings.read_timeout_seconds,...
                this.settings.write_semaphore,this.settings.max_write_permits,this.settings.write_timeout_seconds);
            this.flushAll();
            jUrl.reset_semaphores();
        end
    end
end
