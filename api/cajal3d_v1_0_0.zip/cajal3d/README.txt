######################################################
# (c) 2013 The Johns Hopkins University / Applied Physics Laboratory.
#  All Rights Reserved.
######################################################
#    ReadMe
#
#Author: Dean Kleissas
#Johns Hopkins University, Applied Physics Laboratory
#email: dean.kleissas@jhuapl.edu
#
#                       Revision History
# Author            Date                Comment
# D.Kleissas    26-Aug-2013          Initial Release
#####################################################

   FULL DOCUMENTATION COMING SOON

###################### Overview ######################

This directory contains the CAJAL3D API for MATLAB.  The API provides
RAMON Objects, the OCP unit tests, configuration scripts, and unit tests.


######################  Requirements ######################

Currently MATLAB wrapper for LONI pipline functionality requires Linux or OSX.

All other features should be compatible Windows 7, linux, and OSX.


######################  Set Up  ###################### 

To setup the framework for use on a single computer 
 - Windows:
    - Quick Start 
        - Set MATLAB current folder to the directory where the framework is located
        - Run 'cajal3d' or ' cajal3d.setSearchPath'
        - Edit /test/matlab/api/testMatlabInit.m
            - Change the global variable 'gtestMatlabPath' to the path of your matlab exe.
        - Run all unit tests by setting your current folder to be the root of the framework and
          entering "RUN_TESTS" at the command prompt.

    - If you'd like to have your startup.m configured to setup the search path for you, run
      'setupEnvironment' in the tools directory

 - Linux/OSX:
    - Due to issues with the dynamic java class path compatibility in older versions
      of MATLAB, you must run the setup script to set your static java class path. This
      may change in the future with further testing.
    - Open MATLAB as the user who will be executing the framework
    - Navigate to the framwork directory
    - Navigate to /tools/matlab_install, effectively setting it as the matlab
      current working directory.
    - type 'setupEnvironment' at the MATLAB command prompt and hit enter.  You 
      have 2 options when setting up the framework.  You can have your startup.m
      edited so that all the required items get placed on your search path on 
      the startup of MATLAB, or you can opt-out of this and run 'cajal3d' or
      cajal3d.setSearchPath before using the framework
    - Follow the prompts and your MATLAB environment will be ready
        -- Note you may need to run a generated script as root to setup the java
           class path in matlab if you don't have sudo access for linux/osx.
	- Edit /test/matlab/api/testMatlabInit.m
        -- Change the global variable 'gtestMatlabPath' to equal the path to your matlab exe.
    - Run all unit tests by entering "RUN_TESTS" at the command prompt.

Full configuration of MATLAB environment to use the framework including cluster resources,
including network communication control:
 - If linux, make sure symlink to matlab so calling 'matlab' from the command
   line resolves (ie. a symlink like /usr/bin/matlab
 - If linux add "MATLAB_USE_USERPATH=1" to your .bashrc file. If running on a server
   this can be handled in server configuration
 - If you'd like to control where temporary files are written (important if
   you are managing your temp space) set the environment variable 
   "PIPELINE_TEMP_DIR=/my/location" to your .bashrc file or in the LONI 
   Pipeline Manager.
 - Open MATLAB as the user who will be executing the framework
 - Navigate to the framwork directory
 - Navigate to /tools/matlab_install, effectively setting it as the matlab
   current working directory.
 - type 'setupEnvironment' at the MATLAB command prompt and hit enter.  You 
   have 2 options when setting up the framework.  You can have your startup.m
   edited so that all the required items get placed on your search path on 
   the startup of MATLAB, or you can opt-out of this and run 'cajal3d' or
   cajal3d.setSearchPath before using the framework
 - Follow the prompts and your MATLAB environment will be ready
    -- Note you may need to run a generated script as root to setup the java
       class path in matlab.
 - Install an instance of Redis on your network (see www.redis.io)
 - Configure /api/matlab/ocp/ocp_settings.mat to point to your server on the
   correct port.  Set the number of read/write permits you'd like to use. 
   Typically 50/50 is a good start for most average sized annotations
 - Create a SemaphoreTool object and execute the "resetAll" method:
        s = SemaphoreTool;
        s.resetAll;
 - Edit /test/matlab/api/testMatlabInit.m
    -- Change the global variable 'gtestMatlabPath' to equal the path to your matlab exe.
 - Run all unit tests by setting your matlab path to be the root of the framework and
   entering "RUN_TESTS" at the command prompt.

To set up the Python environment to use the framework:
 - Coming soon...



######################  Usage ###################### 

/api/

    /matlab
        Most functions/classes have comments explaining individual usage.

        This folder contains MATLAB classes and functions to enable
        use of the open connectome project (OCP) services and the LONI pipeline
        based connectome processing pipeline

        - /ocp contains classes for interfacing the OCP
          image data and annotation databases.  The OCP class
          provides methods to upload and download annotation objects, and download
          annotation and image data cutouts, slices, and overlays.  For more 
          information regarding OCP databases and the associated interfaces see: 
          www.openconnecto.me.  Also check out the examples directory.
        - /ramon contains all the RAMON annotation objects.  Classes starting with 
          RAMON* are annotation objects that you can create, manipulate, upload,
          and download.  Classes starting with eRAMON* are enumerations used in 
          the annotation objects.
        - /wrapper contains funtions to wrap matlab code for use inside the
          LONI pipeline framework

/examples
    Examples on how to use the API

/test
    Unit test software
    /matlab
        matlab unit test scripts accessible through the RUN_TESTS function.
        "RUN_TESTS" runs all tests.  "RUN_TESTS('testfile')" runs tests in a
        single file.

/tools
    Scripts and tools for API support


###################### Examples ######################

- See /examples directory

###################### Development ######################

MATLAB:
    ...

Python:
    ...


###################### Notes ######################

Current open image data set tokens: bock11, kasthuri11

Contact OCP for annotation databases.  

Self-adminstration web portal coming soon.

