%% CAJAL3D Demo Script - www.openconnecto.me
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% COPYRIGHT NOTICE
% (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
% All Rights Reserved.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
% you can change the offset to move somewhere else in this database
% so it is clean (since others could have run this script!)
xoff = 40000;
yoff = 40000;
zoff = 3000;

%% Create OCP Interface and set tokens

% Create an OCP object.  This is the main interface with the OCP data
% servers.
oo = OCP();

% To retrieve image data, set an Image Token
oo.setImageToken('bock11');

% To retrieve or write annotations, set an Annotation Token.  Annotation
% tokens are related spatially to a single image data set
oo.setAnnoToken('bock11_examples');
% once you set a token you can get information about that dataset.
oo.imageInfo.DATASET.IMAGE_SIZE(1) % get xy extent at resolution 1

% Set the API default resolution. The OCP server builds a resolution
% hierarchy and all spatial requests or rights must specify the resolution
% to operate at.  By setting this value, if you omit the resolution field
% in future calls it will automatically be used.
oo.setDefaultResolution(1);

%% Get Some Image Data
% build a query. OCPQuery objects contain all information regarding a query
% to a database.  They can be interactive via the validate method to check
% if you've filled things out correctly.  They can be saved and loaded
% which is useful when distributing work across a cluster or pointing a
% colleague to a region of data.
q = OCPQuery(eOCPQueryType.imageDense);

[pf, msg] = q.validate()

q.setCutoutArgs([100 800]+xoff,...
                [100 800]+yoff,...
                [100 130]+zoff,...
                1);
            
[pf, msg] = q.validate()

cutout = oo.query(q);

image(cutout);

%% Create a RAMONSynapse

% EM annotations are represented as RAMON objects in the database.  You can
% create instances of these objects, interact with them in your software,
% and directly upload and download them from the database.

d = ones(256,256,10);

s1 = RAMONSynapse();

s1.setSynapseType(eRAMONSynapseType.excitatory);
s1.setCutout(d);
s1.setXyzOffset([xoff yoff zoff]);
s1.setSeeds([2 4 6 3]);
s1.setConfidence(.8);
s1.setResolution(1);


%% Upload a Synapse
id1 = oo.createAnnotation(s1);

%% Download a Synapse

% The database handles exceptions and passes information to the API.  This
% is an example of quering for an ID that doesn't exist in the database.
sbad = oo.query(OCPQuery(eOCPQueryType.RAMONDense,2534653));

% This is a single line call to query for the synapse you just created.
% Here you create and OCPQuery object that is of type RAMONDense with the
% id 'id1'.  You can also get voxel list and bounding box representations
% of an annotation by changing the eOCPQueryType enumeration.
s2 = oo.query(OCPQuery(eOCPQueryType.RAMONDense,id1));
image(s2);

%% Write annotation with conflict options
% By default writes will "overwrite" existing voxels, but you can also
% upload annotations that will "preserve" existing annotated voxels,
% "reduce" or remove existing voxels that are labeled by your annotation,
% or add and "exception".  Exceptions enable the multiple lables to be
% assigned to a single voxel and must be enabled at database creation time.
%  This is a performance impact, but this is sometimes extremely useful.

d = ones(350,350,10); % write a slightly larger annotation as before

s1 = RAMONSynapse();

s1.setSynapseType(eRAMONSynapseType.excitatory);
s1.setCutout(d);
s1.setXyzOffset([xoff yoff zoff]);
s1.setSeeds([2 4 6 3]);
s1.setConfidence(.8);
s1.setResolution(1);

id1_preserve = oo.createAnnotation(s1,eOCPConflictOption.preserve);
s2_preserve = oo.query(OCPQuery(eOCPQueryType.RAMONDense,id1_preserve));
image(s2_preserve);

%% Update a Synapse

% You can update fields and data in a ramon object. And write it back do
% the database
s2.setWeight(.5);

id2 = oo.updateAnnotation(s2);

% query in 2 lines compared to the single call shown earlier
q = OCPQuery(eOCPQueryType.RAMONDense,id2);
s3 = oo.query(q);


%% Get and Set Fields

% You can directly get and set individual metadata fields for RAMONObjects
% without downloading the whole object.  This works with integers, doubles,
% and strings.  
weight = oo.getField(id2,'weight')
oo.setField(id2,'weight',.25);
weight = oo.getField(id2,'weight')

% If your field isn't in the RAMON Standard definition of an object, it
% gets added as a custom key-value pair.  You will get a warning to help
% prevent typos, but this can be turned off by disabling the
% OCP:CustomKVPair warning
oo.setField(id2,'my_param',2356.356);
param = oo.getField(id2,'my_param')


%% Query for Synapses

% You can query the database for specific things.  Here lets get all RAMON
% objects that are synapses
q = OCPQuery(eOCPQueryType.RAMONIdList);
q.addIdListPredicate(eOCPPredicate.type,eRAMONAnnoType.synapse);

idList = oo.query(q)

% You can also restrict these queries spacially by using the setCutoutArgs
% method of your OCPQuery object.

%% Delete a Synapse

% You can delete any annotation you create.
oo.deleteAnnotation(id2)
idList = oo.query(q)

%% Re-Upload a Synapse object for visualization

d = zeros(200,200,10);
d(30:170,30:170,2:8) = 1;
d(1:170,100:200,2:8) = 1;

s1 = RAMONSynapse();

s1.setSynapseType(eRAMONSynapseType.excitatory);
s1.setCutout(d);
s1.setXyzOffset([xoff yoff zoff+40]);
s1.setSeeds([2 4 6 3]);
s1.setConfidence(.8);
s1.setResolution(1);
id3 = oo.createAnnotation(s1);

%% Download Image and Anno Cutouts based on the annotation

q = OCPQuery(eOCPQueryType.RAMONDense,id3);
anno = oo.query(q);

% Get image of the same saize as the annotation
q_img = anno.toImageDenseQuery;
img = oo.query(q_img);

% visualize data (press 'a' key to toggle annotation on/off, '?' for help)
h = image(img);
h.associate(anno);


