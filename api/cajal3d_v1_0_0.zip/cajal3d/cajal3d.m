classdef cajal3d
    %% cajal3d - CAJAL3D Framework utility Class
    % This function is provided to perform basic configuration, help, and
    % reporting tasks.
    %
    % Supported Uses:
    %
    % Add framework to MATALB search path:
    % >> cajal3d
    %    - or -
    % >> cajal3d.setSearchPath
    %
    % Note: If you have not set your MATLAB installation to automatically
    % add the CAJAL3D framework to the search path at startup using the
    % 'setupEnvironment' script, you must run this everytime MATLAB start
    % before you can use the CAJAL3D framework.
    %
    %
    % Set the current MATLAB folder to the framework path:
    % >> cajal3d.setCurrentFolder
    %
    %
    % Print information to be included in a bug report:
    % >> cajal3d.bugReport
    %
    % Note: Run this command immediately after the error has occured!
    %
    %
    % Print help information:
    % >> cajal3d.help
    %
    %
    % Get the framework version:
    % >> cajal3d.frameworkVersion
    %
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % COPYRIGHT NOTICE
    % (c) 2012 The Johns Hopkins University / Applied Physics Laboratory
    % All Rights Reserved.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    properties(SetAccess = 'private', GetAccess = 'public')
        frameworkRoot = '';
    end
    
    properties(Constant = true)
        frameworkVersion = '1.0.0';
        POC = 'dean.kleissas@jhuapl.edu';
    end
    
    methods
        function this = cajal3d
            % set up search path on constructor
            pathstr = cajal3d.setSearchPath;
            this.frameworkRoot = pathstr;
            
            % if on windows set up dynamic class path
            if ispc
                javaaddpath(fullfile(pathstr,'api','matlab','ocp','cajal3d.jar'));
                % not currently supported - javaaddpath(fullfile(pathstr,'resources','hsqldb','lib','hsqldb.jar'));
            end            
        end
    end
    
    
    methods (Static)
        function bugReport
            err = lasterror; %#ok<LERR>
            clc
            bugStr = sprintf('* Please copy and paste the following report into an email addressed to <a href="mailto:%s?subject=CAJAL3D_Bug_Report">%s</a> *\n',...
                cajal3d.POC,cajal3d.POC);
            bugStr = sprintf('%s* In addition to your contact information, feel free to include *\n* any additional comments and/or attachments that may help debug the issue. *\n\n',bugStr);
            bugStr = sprintf('%s\n<><><><><>  BUG REPORT <><><><><>\n\n',bugStr);
            bugStr = sprintf('%sUserpath Env Var: %s\n\n',bugStr,getenv('MATLAB_USE_USERPATH'));
            bugStr = sprintf('%sArch: %s\n\n',bugStr,computer('arch'));
            bugStr = sprintf('%sOS String: %s\n\n',bugStr,system_dependent('getos'));
            
            if ispc
                platform = [system_dependent('getos'),' ',system_dependent('getwinsys')];
            elseif ismac
                [fail, input] = unix('sw_vers');
                if ~fail
                    platform = strrep(input, 'ProductName:', '');
                    platform = strrep(platform, sprintf('\t'), '');
                    platform = strrep(platform, sprintf('\n'), ' ');
                    platform = strrep(platform, 'ProductVersion:', ' Version: ');
                    platform = strrep(platform, 'BuildVersion:', 'Build: ');
                else
                    platform = system_dependent('getos');
                end
            else
                platform = system_dependent('getos');
            end
            
            % display version
            bugStr = sprintf('%sMATLAB Version: %s\n',bugStr,version);
            
            % display Matlab license number
            bugStr = sprintf('%sMATLAB License Number: %s\n',bugStr,license);
            
            % display os
            bugStr = sprintf('%sOperating System: %s\n',bugStr,platform);
            
            % display first line of Java VM version info
            bugStr = sprintf('%sJava VM Version: %s\n',bugStr,...
                char(strread(version('-java'),'%s',1,'delimiter','\n')));
            
            % toolbox info
            bugStr = sprintf('%s\nToolboxes: \n',bugStr);
            v = ver;
            for k=1:length(v)
                bugStr = sprintf('%s  %s -  Version %s\n', ...
                    bugStr,v(k).Name, v(k).Version);
            end
            
            % system info
            bugStr = sprintf('%s\nCPU: %s\n',bugStr,system_dependent('GetCPU'));
            bugStr = sprintf('%sNum Cores: %d\n',bugStr,system_dependent('NumCores'));
            bugStr = sprintf('%sNum Threads: %d\n',bugStr,system_dependent('NumThreads'));
            
            % pwd
            bugStr = sprintf('%s\nCurrent Working Directory: %s\n',bugStr,pwd);
            [pathstr, ~, ~] = fileparts(which('cajal3d'));
            bugStr = sprintf('%sFramework Directory: %s\n\n',bugStr,pathstr);
            bugStr = sprintf('%sFramework Version: %s\n\n',bugStr,cajal3d.frameworkVersion);
            
            % error info
            errStr = sprintf('Last Error:\n');
            errStr = sprintf('%s Identifier: %s\n',errStr,err.identifier);
            errStr = sprintf('%s Message: %s\n',errStr,err.message);
            errStr = sprintf('%s Cause:\n',errStr);
            
            s = err.stack;
            errStr = sprintf('%s Stack:\n',errStr);
            for ii = 1:length(s)
                fstr = strrep(s(ii).file,'\','\\');
                errStr = sprintf('%s\n  File: %s \n',errStr,fstr);
                errStr = sprintf('%s  Method: %s \n',errStr,s(ii).name);
                errStr = sprintf('%s  Line: %d \n',errStr,s(ii).line);
            end
            
            bugStr = sprintf('%s%s\n\n',bugStr,errStr);
            
            bugStr = sprintf('%sDescription of Problem: \n\n',bugStr);
            bugStr = sprintf('%s   - - Please fill out in email - - \n\n',bugStr);
            
            
            bugStr = sprintf('%sComments: \n\n',bugStr);
            bugStr = sprintf('%s   - - Please fill out in email - - \n\n',bugStr);
            
            
            bugStr = sprintf('%s\nPlease copy and paste the above report into an email addressed to  <a href="mailto:%s?subject=CAJAL3D_Bug_Report">%s</a>.\n\n\n',...
                bugStr,cajal3d.POC,cajal3d.POC);
            
            fprintf('%s',bugStr);
        end
        
        function pathstr = setSearchPath
            [pathstr, ~, ~] = fileparts(which('cajal3d'));
            addpath(genpath(pathstr));
        end
        
        function setCurrentFolder
            [pathstr, ~, ~] = fileparts(which('cajal3d'));
            cd(pathstr);            
        end
        
        function help
            fprintf('Help coming soon...\n');
        end
        
    end
    
end

